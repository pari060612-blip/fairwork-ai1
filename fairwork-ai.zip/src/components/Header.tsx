import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Clock,
  FileText,
  AlertTriangle,
  MessageSquare,
  Award,
  Activity,
  LayoutDashboard,
  Menu,
  X,
  Shield,
  Briefcase
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    t,
    role,
    setRole,
    sector,
    activeTab,
    setActiveTab,
    activeWorker,
    currentShift
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const workerNavItems = [
    { id: 'shifts', label: t.navShifts, icon: Clock },
    { id: 'payslip', label: t.navPayslip, icon: FileText },
    { id: 'safety', label: t.navSafety, icon: AlertTriangle },
    { id: 'feedback', label: t.navFeedback, icon: MessageSquare },
    { id: 'skills', label: t.navSkills, icon: Award },
    { id: 'fatigue', label: t.navFatigue, icon: Activity },
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab(role === 'admin' ? 'admin' : 'shifts')}
              className="text-xl font-bold tracking-tight text-slate-900 whitespace-nowrap flex items-center gap-2 hover:opacity-90 transition-opacity"
            >
              <span className="w-8 h-8 rounded-lg bg-teal-800 text-white flex items-center justify-center text-sm font-extrabold shadow-sm">
                FW
              </span>
              <span>FairWork <span className="text-teal-700">AI</span></span>
            </button>
            <div className="hidden sm:flex items-center text-xs text-slate-400">
              <span>·</span>
              <span className="ml-2 capitalize text-slate-500 font-medium">{sector} Division</span>
            </div>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-600">
            {role === 'worker' ? (
              workerNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleNavClick(item.id)}
                    className={`flex items-center gap-1.5 py-1 whitespace-nowrap shrink-0 transition-colors ${
                      isActive
                        ? 'text-teal-900 font-semibold border-b-2 border-teal-700'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </button>
                );
              })
            ) : (
              <div className="flex items-center gap-6">
                <button
                  type="button"
                  onClick={() => setActiveTab('admin')}
                  className={`flex items-center gap-1.5 py-1 whitespace-nowrap shrink-0 transition-colors ${
                    activeTab === 'admin'
                      ? 'text-teal-900 font-semibold border-b-2 border-teal-700'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <LayoutDashboard className="w-4 h-4" />
                  <span>{t.navAdmin}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setRole('worker');
                    setActiveTab('safety');
                  }}
                  className="flex items-center gap-1 text-slate-500 hover:text-slate-900 text-xs transition-colors"
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Report Worker Hazard</span>
                </button>
              </div>
            )}
          </nav>

          {/* Zone 3: Active Profile & Primary Action */}
          <div className="flex items-center gap-3 shrink-0">
            {role === 'worker' ? (
              <div className="flex items-center gap-2.5">
                <div className="hidden md:flex flex-col text-right">
                  <span className="text-xs font-semibold text-slate-900 leading-tight">
                    {activeWorker.name}
                  </span>
                  <span className="text-[11px] text-slate-500 truncate max-w-[170px]">
                    {activeWorker.role}
                  </span>
                </div>
                <div
                  className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 text-teal-900 font-semibold flex items-center justify-center text-xs shadow-2xs"
                  title={`${activeWorker.name} (${activeWorker.id})`}
                >
                  {activeWorker.avatarText}
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('shifts')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                    currentShift
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-teal-800 hover:bg-teal-900 text-white shadow-xs'
                  }`}
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>{currentShift ? t.checkedInState : t.checkIn}</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <div className="hidden md:flex items-center gap-2 text-xs text-slate-600 bg-slate-50 px-2.5 py-1 rounded-md border border-slate-200">
                  <Shield className="w-3.5 h-3.5 text-teal-700" />
                  <span className="font-semibold text-slate-800">Admin Operations</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setRole('worker');
                    setActiveTab('shifts');
                  }}
                  className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
                >
                  <Briefcase className="w-3.5 h-3.5 text-slate-500" />
                  <span>View Worker View</span>
                </button>
              </div>
            )}

            {/* Mobile Hamburger Button */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100 focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-4 space-y-1">
          <div className="p-2 mb-2 bg-slate-50 rounded-lg text-xs flex items-center justify-between text-slate-600">
            <span>Viewing as: <strong className="text-slate-900">{activeWorker.name}</strong></span>
            <span className="text-teal-800 font-semibold">{sector}</span>
          </div>

          {role === 'worker' ? (
            workerNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-teal-50 text-teal-900 font-semibold'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <Icon className="w-4 h-4 text-slate-500" />
                  <span>{item.label}</span>
                </button>
              );
            })
          ) : (
            <button
              type="button"
              onClick={() => handleNavClick('admin')}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium bg-teal-50 text-teal-900 font-semibold"
            >
              <LayoutDashboard className="w-4 h-4 text-teal-800" />
              <span>{t.navAdmin}</span>
            </button>
          )}
        </div>
      )}
    </header>
  );
};
