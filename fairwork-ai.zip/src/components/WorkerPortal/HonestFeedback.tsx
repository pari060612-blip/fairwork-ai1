import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { VoiceInputButton } from '../VoiceInputButton';
import {
  MessageSquare,
  ShieldCheck,
  Lock,
  Send,
  Star,
  CheckCircle2,
  AlertTriangle,
  Info
} from 'lucide-react';

export const HonestFeedback: React.FC = () => {
  const {
    t,
    sector,
    activeWorker,
    feedbackEntries,
    addFeedback,
  } = useApp();

  const [topic, setTopic] = useState('');
  const [rating, setRating] = useState<number>(4);
  const [message, setMessage] = useState('');
  const [sentiment, setSentiment] = useState<'positive' | 'neutral' | 'concern'>('neutral');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const topics =
    sector === 'construction'
      ? [
          'Shift Scheduling & Overtime Advance Notice',
          'Break Facilities, Drinking Water & Heat Relief',
          'Site Supervisor Communication & Respect',
          'Quality of Personal Protective Equipment (PPE)',
          'Heavy Machinery Safety & Traffic Coordination',
          'Sanitation, Washrooms & Changing Areas',
        ]
      : [
          'Examination Grading Turnaround & Deadlines',
          'Research Lab Consumable Restocking Speed',
          'Department Head Workload Distribution',
          'Ergonomic Workstations & Lecture Hall Facilities',
          'Student Safety Protocols in Practical Labs',
          'Administrative Duty Burden vs Teaching Time',
        ];

  const handleVoiceTranscript = (text: string) => {
    setMessage((prev) => (prev ? `${prev} ${text}` : text));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic || !message.trim()) {
      setError('Please select a feedback category and enter your message.');
      return;
    }
    setError(null);

    addFeedback({
      workerId: activeWorker.id,
      sector,
      topic,
      rating,
      message: message.trim(),
      sentiment,
      isConfidential: true,
    });

    setIsSubmitted(true);
    setMessage('');
    setTopic('');
    setTimeout(() => setIsSubmitted(false), 6000);
  };

  const sectorFeedback = feedbackEntries.filter((f) => f.sector === sector);

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="pb-4 border-b border-slate-200">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          {t.feedbackTitle}
        </h1>
        <p className="text-sm text-slate-500 mt-1 max-w-2xl">
          {t.feedbackSubtitle} Help leadership spot organizational bottlenecks and improve site safety culture.
        </p>
      </div>

      {/* Mandatory Confidentiality vs Technical Anonymity Education Banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-800 shadow-xs">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-teal-800/80 text-teal-300 flex items-center justify-center shrink-0">
            <Lock className="w-5 h-5" />
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white">
                {t.feedbackNoticeTitle}
              </h2>
              <span className="text-[10px] uppercase font-bold tracking-wider text-teal-400 bg-teal-950/60 px-2 py-0.5 rounded border border-teal-800">
                Ethical Disclosure
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
              {t.feedbackNoticeBody} Your identity is permanently masked from site foremen and peer workers.
              Aggregated themes are presented to senior management to protect psychological safety.
            </p>
          </div>
        </div>
      </div>

      {/* Success Notification */}
      {isSubmitted && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center gap-3 animate-in fade-in duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" />
          <p className="text-xs font-semibold text-emerald-900">
            {t.feedbackSuccess}
          </p>
        </div>
      )}

      {/* Form & Recent Themes Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Feedback Input Form */}
        <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <h3 className="text-base font-bold text-slate-900 pb-3 border-b border-slate-100 mb-4">
            Share Feedback ({sector === 'construction' ? 'SRM Construction Site' : 'SRMIST Academic Block'})
          </h3>

          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
                {error}
              </div>
            )}

            {/* Category */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.feedbackTopic} <span className="text-rose-500">*</span>
              </label>
              <select
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-700"
                required
              >
                <option value="">Select a relevant workplace topic...</option>
                {topics.map((top) => (
                  <option key={top} value={top}>
                    {top}
                  </option>
                ))}
              </select>
            </div>

            {/* Rating */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t.ratingLabel} (1 to 5)
              </label>
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => {
                      setRating(star);
                      if (star <= 2) setSentiment('concern');
                      else if (star === 3) setSentiment('neutral');
                      else setSentiment('positive');
                    }}
                    className={`p-2 rounded-lg border transition-colors flex items-center gap-1 text-xs font-semibold ${
                      rating === star
                        ? 'bg-teal-800 text-white border-teal-800 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <Star className={`w-3.5 h-3.5 ${rating >= star ? 'fill-current' : ''}`} />
                    <span>{star}</span>
                  </button>
                ))}
                <span className="text-xs text-slate-500 ml-2">
                  {rating <= 2 ? 'Needs urgent improvement' : rating === 3 ? 'Neutral / Satisfactory' : 'Strong & Positive'}
                </span>
              </div>
            </div>

            {/* Message with Voice Input */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-700">
                  {t.feedbackMessage} <span className="text-rose-500">*</span>
                </label>
                <VoiceInputButton onTranscript={handleVoiceTranscript} />
              </div>
              <textarea
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Describe your constructive suggestion, specific incident, or leadership advice..."
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-3 text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-700 leading-relaxed"
                required
              />
              <div className="mt-1 text-[11px] text-slate-400">
                🔒 Protected: Your name and badge ID will NEVER be displayed publicly or shared with team leads.
              </div>
            </div>

            {/* Submit */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-2.5 px-4 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors flex items-center justify-center gap-2 shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{t.submitFeedback}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Right Column: Confidential Feedback Themes Stream */}
        <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">
              Aggregated Feedback Topics ({sectorFeedback.length})
            </h3>
            <span className="text-[11px] text-slate-400">Anonymous Feed</span>
          </div>

          <div className="divide-y divide-slate-100 space-y-3">
            {sectorFeedback.map((entry) => (
              <div key={entry.id} className="pt-3 first:pt-0 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-900">
                    {entry.topic}
                  </span>
                  <div className="flex items-center gap-1 text-amber-500 text-xs">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    <span className="font-mono tabular-nums text-slate-800 font-bold">{entry.rating}/5</span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 italic">
                  "{entry.message}"
                </p>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                  <span>Author: <strong className="text-slate-600 font-normal">Confidential Verified Personnel</strong></span>
                  <span className="font-mono">{entry.timestamp}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
