import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Award,
  ShieldCheck,
  CheckCircle,
  PlusCircle,
  Printer,
  FileCheck2,
  Calendar,
  Clock,
  ExternalLink,
  UserCheck,
  AlertCircle
} from 'lucide-react';
import { SkillCredential } from '../../types';

export const SkillPassport: React.FC = () => {
  const {
    t,
    activeWorker,
    sector,
    skills,
    addSkillRecord,
  } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [issuingAuthority, setIssuingAuthority] = useState('');
  const [issueDate, setIssueDate] = useState(new Date().toISOString().split('T')[0]);
  const [trainingHours, setTrainingHours] = useState<number>(20);
  const [verificationType, setVerificationType] = useState<'verified_official' | 'self_reported'>('self_reported');
  const [description, setDescription] = useState('');
  const [credentialId, setCredentialId] = useState('');

  // Filter skills for active worker
  const workerSkills = skills.filter((s) => s.workerId === activeWorker.id);
  const verifiedCount = workerSkills.filter((s) => s.verificationType === 'verified_official').length;
  const totalTrainingHours = workerSkills.reduce((acc, s) => acc + s.trainingHours, 0);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !category.trim()) return;

    addSkillRecord({
      workerId: activeWorker.id,
      sector,
      title: title.trim(),
      category: category.trim(),
      issuingAuthority: issuingAuthority.trim() || (verificationType === 'verified_official' ? 'Accredited Safety Council' : 'Self-Reported Experience'),
      issueDate,
      verificationType,
      credentialId: credentialId.trim() || (verificationType === 'verified_official' ? `VER-${Date.now().toString().slice(-6)}` : undefined),
      description: description.trim(),
      trainingHours: Number(trainingHours) || 10,
    });

    setTitle('');
    setCategory('');
    setIssuingAuthority('');
    setDescription('');
    setCredentialId('');
    setIsModalOpen(false);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200 no-print">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            {t.passportTitle}
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            {t.passportSubtitle} Portable credential ledger distinguishing audited certifications from self-reported experience.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors shadow-xs"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
            <span>{t.downloadSummary}</span>
          </button>
          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-teal-800 hover:bg-teal-900 rounded-xl transition-colors shadow-xs"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>{t.addRecord}</span>
          </button>
        </div>
      </div>

      {/* KPI Overview Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 no-print">
        <div className="bg-white p-5 rounded-xl border border-slate-200 flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-medium">Verified Credentials</span>
            <p className="text-2xl font-bold font-mono text-slate-900 mt-1">{verifiedCount}</p>
            <span className="text-[11px] text-emerald-700">Third-Party & Employer Audited</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-medium">Self-Reported Proficiencies</span>
            <p className="text-2xl font-bold font-mono text-slate-900 mt-1">
              {workerSkills.length - verifiedCount}
            </p>
            <span className="text-[11px] text-slate-500">Subject to Site Lead Verification</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center">
            <UserCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-medium">{t.trainingHours}</span>
            <p className="text-2xl font-bold font-mono text-slate-900 mt-1">
              {totalTrainingHours} <span className="text-xs font-normal text-slate-400">hours</span>
            </p>
            <span className="text-[11px] text-teal-700">Cumulative Safety & Craft Logs</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-800 flex items-center justify-center">
            <Clock className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Credentials Feed */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 md:p-8 space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Credentials & Professional Ledger
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Issued for: <strong className="text-slate-800">{activeWorker.name}</strong> ({activeWorker.id})
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="inline-flex items-center gap-1 text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{t.verifiedCredential}</span>
            </span>
            <span className="inline-flex items-center gap-1 text-slate-600 bg-slate-100 px-2.5 py-1 rounded-md border border-slate-200">
              <UserCheck className="w-3.5 h-3.5" />
              <span>{t.selfReported}</span>
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {workerSkills.map((skill) => {
            const isVerified = skill.verificationType === 'verified_official';
            return (
              <div
                key={skill.id}
                className={`p-5 rounded-xl border transition-all ${
                  isVerified
                    ? 'border-emerald-200/80 bg-white hover:border-emerald-300 shadow-2xs'
                    : 'border-slate-200 bg-slate-50/50 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[11px] uppercase tracking-wider font-semibold text-teal-800 block mb-1">
                      {skill.category}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 leading-snug">
                      {skill.title}
                    </h3>
                  </div>
                  {isVerified ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 shrink-0">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      Verified
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-600 bg-slate-200/60 px-2 py-0.5 rounded shrink-0">
                      Self-Reported
                    </span>
                  )}
                </div>

                <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                  {skill.description}
                </p>

                <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
                  <div>
                    Issuing Authority: <strong className="text-slate-700">{skill.issuingAuthority}</strong>
                  </div>
                  {skill.credentialId && (
                    <div>
                      ID: <span className="font-mono text-slate-800">{skill.credentialId}</span>
                    </div>
                  )}
                </div>

                <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Issued: {skill.issueDate}</span>
                  <span>{skill.trainingHours} Certified Hours</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Skill Record Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {t.addRecord}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Expand your professional passport with verified courses or experience
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Credential / Skill Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Scaffolding Load Certification or HPLC Chromatography"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 focus:ring-1 focus:ring-teal-700"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Category <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Safety, Craft, Lab Operations"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 focus:ring-1 focus:ring-teal-700"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Completed Training Hours
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={trainingHours}
                    onChange={(e) => setTrainingHours(Number(e.target.value))}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Verification Classification
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setVerificationType('verified_official')}
                    className={`p-2.5 rounded-lg border text-xs font-medium text-left transition-colors ${
                      verificationType === 'verified_official'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-semibold'
                        : 'border-slate-200 bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="font-semibold flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                      Verified Credential
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Has certificate ID & issuing body</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setVerificationType('self_reported')}
                    className={`p-2.5 rounded-lg border text-xs font-medium text-left transition-colors ${
                      verificationType === 'self_reported'
                        ? 'border-slate-800 bg-slate-100 text-slate-900 font-semibold'
                        : 'border-slate-200 bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="font-semibold flex items-center gap-1">
                      <UserCheck className="w-3.5 h-3.5 text-slate-700" />
                      Self-Reported
                    </div>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Hands-on experience / ongoing</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Issuing Authority / Provider
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. National Safety Council or SRMIST"
                    value={issuingAuthority}
                    onChange={(e) => setIssuingAuthority(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Certificate Serial / ID (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. NSC-2026-991"
                    value={credentialId}
                    onChange={(e) => setCredentialId(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Competency Description
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Detail tools operated, safety protocols mastered, and tasks performed..."
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-teal-800 hover:bg-teal-900 rounded-lg transition-colors shadow-xs"
                >
                  Save Credential
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
