import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Activity,
  AlertTriangle,
  Sliders,
  ShieldAlert,
  Clock,
  CheckCircle,
  Calendar,
  Info,
  HeartPulse
} from 'lucide-react';

export const FatigueMonitor: React.FC = () => {
  const {
    t,
    activeWorker,
    sector,
    thresholds,
    updateThresholds,
    fatigueAlerts,
    shifts,
  } = useApp();

  const [isConfiguring, setIsConfiguring] = useState(false);
  const [maxHoursInput, setMaxHoursInput] = useState(thresholds.maxDailyHours);
  const [minRestInput, setMinRestInput] = useState(thresholds.minTurnaroundHours);
  const [maxConsecutiveInput, setMaxConsecutiveInput] = useState(thresholds.maxConsecutiveDays);

  const handleSaveThresholds = (e: React.FormEvent) => {
    e.preventDefault();
    updateThresholds({
      maxDailyHours: Number(maxHoursInput),
      minTurnaroundHours: Number(minRestInput),
      maxConsecutiveDays: Number(maxConsecutiveInput),
    });
    setIsConfiguring(false);
  };

  // Filter alerts for active worker and sector
  const workerAlerts = fatigueAlerts.filter(
    (a) => a.workerId === activeWorker.id || a.sector === sector
  );

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            {t.fatigueTitle}
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            {t.fatigueSubtitle} Prevent exhaustion-induced accidents with clear, transparent workload thresholds.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsConfiguring(!isConfiguring)}
          className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors shadow-xs"
        >
          <Sliders className="w-3.5 h-3.5 text-teal-700" />
          <span>{isConfiguring ? 'Hide Threshold Settings' : 'Configure Safety Thresholds'}</span>
        </button>
      </div>

      {/* Mandatory Explicit Non-Medical Disclaimer */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
        <HeartPulse className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
        <div>
          <h2 className="text-xs font-bold text-amber-900 uppercase tracking-wider">
            Important Safety & Health Notice
          </h2>
          <p className="text-xs text-amber-900 leading-relaxed mt-0.5">
            {t.fatigueDisclaimer} FairWork AI monitors mathematical time allocations and rest intervals mandated by safety policies. If you experience physical dizziness, severe dehydration, or cognitive fatigue, stop work immediately and seek medical attention from on-site first aid.
          </p>
        </div>
      </div>

      {/* Threshold Configurator Panel */}
      {isConfiguring && (
        <form onSubmit={handleSaveThresholds} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4 animate-in fade-in duration-150">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900">
              Demo Workload Policy Settings
            </h3>
            <span className="text-xs text-slate-400">Interactive rule parameters</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.maxDailyHours} (Hours)
              </label>
              <input
                type="number"
                min="6"
                max="16"
                step="0.5"
                value={maxHoursInput}
                onChange={(e) => setMaxHoursInput(Number(e.target.value))}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 font-mono"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Standard legal limit: 10h in India Factory Act
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.minRestBetweenShifts} (Hours)
              </label>
              <input
                type="number"
                min="6"
                max="16"
                step="0.5"
                value={minRestInput}
                onChange={(e) => setMinRestInput(Number(e.target.value))}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 font-mono"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Minimum circadian turnaround interval
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.maxConsecutiveDays} (Days)
              </label>
              <input
                type="number"
                min="4"
                max="14"
                value={maxConsecutiveInput}
                onChange={(e) => setMaxConsecutiveInput(Number(e.target.value))}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 font-mono"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Mandatory weekly rest cycle
              </span>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsConfiguring(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 text-xs font-semibold text-white bg-teal-800 hover:bg-teal-900 rounded-lg"
            >
              Update Thresholds
            </button>
          </div>
        </form>
      )}

      {/* Active Thresholds Summary Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 font-medium">{t.maxDailyHours}</span>
          <p className="mt-1 text-2xl font-bold font-mono text-slate-900">
            {thresholds.maxDailyHours} <span className="text-xs font-normal text-slate-500">hours/shift</span>
          </p>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            Triggers overtime exhaustion flag
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 font-medium">{t.minRestBetweenShifts}</span>
          <p className="mt-1 text-2xl font-bold font-mono text-slate-900">
            {thresholds.minTurnaroundHours} <span className="text-xs font-normal text-slate-500">hours rest</span>
          </p>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            Back-to-back shift turnaround minimum
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 font-medium">{t.maxConsecutiveDays}</span>
          <p className="mt-1 text-2xl font-bold font-mono text-slate-900">
            {thresholds.maxConsecutiveDays} <span className="text-xs font-normal text-slate-500">days max</span>
          </p>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            Guarantees 24h statutory recovery
          </span>
        </div>
      </div>

      {/* Real Fatigue Warnings Feed */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Active Workload & Fatigue Advisories ({workerAlerts.length})
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Transparent mathematical reasoning showing specific hours and policy limits.
            </p>
          </div>
        </div>

        <div className="space-y-4">
          {workerAlerts.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-400">
              All shifts currently comply with safe rest and turnaround policies.
            </div>
          ) : (
            workerAlerts.map((alert) => {
              const badgeColor = {
                moderate: 'text-amber-800 bg-amber-50 border-amber-200',
                high: 'text-orange-800 bg-orange-50 border-orange-200',
                severe: 'text-rose-800 bg-rose-50 border-rose-200',
              }[alert.severity];

              return (
                <div
                  key={alert.id}
                  className="p-5 rounded-xl border border-slate-200 bg-slate-50/40 space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-700" />
                      <h3 className="text-sm font-bold text-slate-900">
                        {alert.workerName} ({alert.departmentOrSite})
                      </h3>
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider border ${badgeColor}`}>
                      {alert.severity} Risk
                    </span>
                  </div>

                  {/* Mathematical Trigger Reason */}
                  <div className="bg-white p-3.5 rounded-lg border border-slate-200 text-xs text-slate-700 space-y-1">
                    <strong className="block text-slate-900 font-semibold">
                      Mathematical Trigger Reason:
                    </strong>
                    <p className="leading-relaxed">{alert.triggerReason}</p>
                    <div className="flex flex-wrap gap-4 text-[11px] text-slate-500 pt-1 font-mono">
                      <span>Logged: <strong>{alert.loggedHours}h</strong></span>
                      <span>Threshold: <strong>{alert.thresholdHours}h</strong></span>
                      {alert.turnaroundHours && (
                        <span>Turnaround Rest: <strong>{alert.turnaroundHours}h</strong></span>
                      )}
                      <span>Consecutive Days: <strong>{alert.consecutiveDays} days</strong></span>
                    </div>
                  </div>

                  {/* Recommended Action */}
                  <div className="text-xs text-slate-600 flex items-start gap-2 bg-teal-50/50 p-3 rounded-lg border border-teal-100">
                    <Info className="w-4 h-4 text-teal-700 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-teal-900 block font-semibold">
                        Recommended Operational Remedy:
                      </strong>
                      <p className="mt-0.5 text-slate-700">{alert.recommendedAction}</p>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
