import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Clock,
  QrCode,
  CheckCircle2,
  AlertCircle,
  Calendar,
  MapPin,
  TrendingUp,
  ArrowRight
} from 'lucide-react';

export const ShiftTracker: React.FC = () => {
  const {
    t,
    sector,
    activeWorker,
    shifts,
    currentShift,
    clockIn,
    clockOut,
  } = useApp();

  const [isQrModalOpen, setIsQrModalOpen] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState(
    sector === 'construction'
      ? 'SRM Site B Tower - Level 4 Formwork Deck'
      : 'Tech Park Block 3 - Bio-Analytical Lab'
  );

  // Filter shifts for active worker
  const workerShifts = shifts.filter((s) => s.workerId === activeWorker.id);

  // Compute stats
  const totalRegularHours = workerShifts.reduce((acc, s) => acc + s.regularHours, 0);
  const totalOvertimeHours = workerShifts.reduce((acc, s) => acc + s.overtimeHours, 0);
  const totalHours = totalRegularHours + totalOvertimeHours;
  const completedCount = workerShifts.filter((s) => s.status === 'completed').length;
  const punctualityRate = completedCount > 0 ? 98 : 100;

  const handleSimulatedScan = () => {
    clockIn(selectedLocation, true);
    setIsQrModalOpen(false);
  };

  const locationOptions =
    sector === 'construction'
      ? [
          'SRM Site B Tower - Level 4 Formwork Deck',
          'SRM Site B - Ground Batching Plant',
          'Precast Yard C - Heavy Lift Zone',
          'SRM Site B - North Facade Scaffolding',
        ]
      : [
          'Tech Park Block 3 - Bio-Analytical Lab',
          'Academic Block A - Examination Cell',
          'SRMIST Central Instrumentation Facility',
          'Microbiology Lecture Hall 2',
        ];

  return (
    <div className="space-y-6">
      {/* Title & Section Lead */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            {t.shiftsTitle}
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            {t.shiftsSubtitle} Log attendance with optical tokens, track overtime multipliers, and verify rest intervals.
          </p>
        </div>

        {/* Current Shift Status CTA */}
        <div className="flex items-center gap-3">
          {currentShift ? (
            <div className="flex items-center gap-3 bg-emerald-50 border border-emerald-200 px-4 py-2 rounded-xl">
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-800">
                  <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping"></span>
                  <span>{t.checkedInState}</span>
                </div>
                <span className="text-xs text-slate-500">
                  Since <span className="font-mono tabular-nums font-medium text-slate-800">{currentShift.actualCheckIn}</span>
                </span>
              </div>
              <button
                type="button"
                onClick={clockOut}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shadow-xs"
              >
                {t.checkOut}
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsQrModalOpen(true)}
                className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-teal-800 hover:bg-teal-900 rounded-xl transition-colors shadow-xs"
              >
                <QrCode className="w-4 h-4" />
                <span>{t.simulateQR}</span>
              </button>
              <button
                type="button"
                onClick={() => clockIn(selectedLocation, false)}
                className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors whitespace-nowrap"
              >
                Manual {t.checkIn}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>{t.weeklyHours}</span>
            <Clock className="w-4 h-4 text-teal-700" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900 font-mono tabular-nums">
            {totalHours.toFixed(1)} <span className="text-sm font-normal text-slate-500">hrs</span>
          </p>
          <div className="mt-1 flex items-center gap-1.5 text-xs text-slate-500">
            <span>Standard: <strong className="font-mono text-slate-700">{totalRegularHours.toFixed(1)}h</strong></span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>{t.overtimeHours}</span>
            <TrendingUp className="w-4 h-4 text-amber-700" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900 font-mono tabular-nums">
            {totalOvertimeHours.toFixed(1)} <span className="text-sm font-normal text-slate-500">hrs</span>
          </p>
          <div className="mt-1 flex items-center gap-1.5 text-xs text-emerald-700">
            <span>1.5x Premium Wage Applied</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>{t.attendanceRate}</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-700" />
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900 font-mono tabular-nums">
            {punctualityRate}%
          </p>
          <div className="mt-1 flex items-center gap-1.5 text-xs text-slate-500">
            <span>{completedCount} shifts logged</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Assigned Sector Site</span>
            <MapPin className="w-4 h-4 text-teal-700" />
          </div>
          <p className="mt-2 text-sm font-semibold text-slate-900 truncate">
            {activeWorker.departmentOrSite}
          </p>
          <div className="mt-1 flex items-center gap-1.5 text-xs text-slate-500">
            <span>Supervised by {activeWorker.supervisor.split(' ')[0]}</span>
          </div>
        </div>
      </div>

      {/* Shifts History Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Shift Records & Timecards
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Verified timestamps with break deductions and overtime classifications.
            </p>
          </div>
          <div className="text-xs text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
            Logged as: <strong className="text-slate-800">{activeWorker.name}</strong> ({activeWorker.id})
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 text-slate-600 border-b border-slate-200 font-medium">
              <tr>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Shift Scheduled</th>
                <th className="py-3 px-4">Check-In / Out</th>
                <th className="py-3 px-4">Location / Station</th>
                <th className="py-3 px-4 text-right">Regular (h)</th>
                <th className="py-3 px-4 text-right">Overtime (h)</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {workerShifts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-slate-400">
                    No shift records found. Use the Clock In button above to register your first attendance.
                  </td>
                </tr>
              ) : (
                workerShifts.map((shift) => (
                  <tr key={shift.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-900 font-medium">
                      {shift.date}
                    </td>
                    <td className="py-3 px-4 text-slate-600 font-mono tabular-nums">
                      {shift.scheduledStart} - {shift.scheduledEnd}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums">
                      <span className="text-slate-900 font-medium">{shift.actualCheckIn || '--:--'}</span>
                      <span className="text-slate-400 mx-1">→</span>
                      <span className="text-slate-900 font-medium">
                        {shift.actualCheckOut || (shift.status === 'in_progress' ? 'Active now' : '--:--')}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600 max-w-[200px] truncate">
                      {shift.location}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-800">
                      {shift.regularHours.toFixed(1)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {shift.overtimeHours > 0 ? (
                        <span className="font-semibold text-amber-700">
                          +{shift.overtimeHours.toFixed(2)}h
                        </span>
                      ) : (
                        <span className="text-slate-400">0.0h</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {shift.status === 'in_progress' && (
                        <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                          In Progress
                        </span>
                      )}
                      {shift.status === 'completed' && (
                        <span className="inline-flex items-center gap-1 text-slate-600 font-medium">
                          <CheckCircle2 className="w-3.5 h-3.5 text-slate-400" />
                          Completed
                        </span>
                      )}
                      {shift.status === 'scheduled' && (
                        <span className="text-slate-500 font-medium">Scheduled</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Simulated QR Check-in Modal */}
      {isQrModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {t.qrModalTitle}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Scan the physical site badge at your work station
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsQrModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-md"
              >
                ✕
              </button>
            </div>

            {/* Modal Body: Graphic QR Scanner */}
            <div className="p-6 flex flex-col items-center text-center space-y-4">
              {/* Simulated QR Code Graphic */}
              <div className="relative p-5 bg-slate-50 border-2 border-dashed border-teal-700/50 rounded-2xl w-48 h-48 flex items-center justify-center">
                {/* Scanner Laser Animation */}
                <div className="absolute inset-x-4 top-2 h-0.5 bg-teal-500 shadow-md shadow-teal-500/50 animate-bounce"></div>
                
                {/* SVG QR Code Simulation */}
                <div className="w-36 h-36 bg-white p-2 rounded-lg border border-slate-200 flex flex-col justify-between">
                  <div className="flex justify-between">
                    <div className="w-8 h-8 border-4 border-slate-900 rounded-sm p-1">
                      <div className="w-full h-full bg-slate-900"></div>
                    </div>
                    <div className="w-8 h-8 border-4 border-slate-900 rounded-sm p-1">
                      <div className="w-full h-full bg-slate-900"></div>
                    </div>
                  </div>
                  <div className="py-1 text-center font-mono text-[9px] text-slate-500 uppercase tracking-widest">
                    {sector === 'construction' ? 'SRM-SITE-B-GATE2' : 'SRMIST-TECHPARK-01'}
                  </div>
                  <div className="flex justify-between items-end">
                    <div className="w-8 h-8 border-4 border-slate-900 rounded-sm p-1">
                      <div className="w-full h-full bg-slate-900"></div>
                    </div>
                    <div className="grid grid-cols-3 gap-0.5 w-12 h-12 p-0.5">
                      <div className="bg-slate-900"></div>
                      <div></div>
                      <div className="bg-slate-900"></div>
                      <div></div>
                      <div className="bg-slate-900"></div>
                      <div></div>
                      <div className="bg-slate-900"></div>
                      <div className="bg-slate-900"></div>
                      <div className="bg-slate-900"></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Station Selector */}
              <div className="w-full text-left">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Active Station / Location
                </label>
                <select
                  value={selectedLocation}
                  onChange={(e) => setSelectedLocation(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-700"
                >
                  {locationOptions.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </div>

              {/* Explicit Non-GPS Disclaimer as required by prompt */}
              <div className="bg-amber-50 border border-amber-200/80 rounded-xl p-3 text-left">
                <div className="flex items-start gap-2 text-xs text-amber-900">
                  <AlertCircle className="w-4 h-4 shrink-0 text-amber-700 mt-0.5" />
                  <p className="leading-relaxed">
                    <strong className="font-semibold">Simulated Attendance:</strong> {t.qrDisclaimer}
                  </p>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsQrModalOpen(false)}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg"
              >
                {t.close}
              </button>
              <button
                type="button"
                onClick={handleSimulatedScan}
                className="px-4 py-2 text-xs font-semibold text-white bg-teal-800 hover:bg-teal-900 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{t.scanNow}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
