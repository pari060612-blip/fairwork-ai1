import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { VoiceInputButton } from '../VoiceInputButton';
import {
  AlertTriangle,
  Camera,
  CheckCircle2,
  Clock,
  MapPin,
  Send,
  Upload,
  ShieldAlert,
  ChevronRight,
  Filter,
  Check
} from 'lucide-react';
import { SafetySeverity, SafetyStatus, SafetyReport } from '../../types';

export const SafetyReporter: React.FC = () => {
  const {
    t,
    sector,
    activeWorker,
    safetyReports,
    addSafetyReport,
  } = useApp();

  const [category, setCategory] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [severity, setSeverity] = useState<SafetySeverity>('high');
  const [location, setLocation] = useState('');
  const [imageCaption, setImageCaption] = useState('');
  const [selectedPresetImage, setSelectedPresetImage] = useState<string | null>(null);
  const [lastSubmittedId, setLastSubmittedId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<'all' | SafetyStatus>('all');
  const [validationError, setValidationError] = useState<string | null>(null);

  // Sector-tailored hazard categories
  const categories =
    sector === 'construction'
      ? [
          'Fall Hazard & Scaffolding Instability',
          'Heavy Machinery & Crane Swing Radius',
          'Electrical Exposure & Cable Damage',
          'Heat Exhaustion & Hydration Deficit',
          'Structural Shuttering / Formwork Defect',
          'Missing PPE (Hardhat / Harness / Boots)',
        ]
      : [
          'Chemical Fume Hood & Toxic Vapor',
          'Electrical Hazard & Exposed Wiring',
          'Ergonomic Strain / Repetitive Workload',
          'Emergency Fire Stairwell Obstruction',
          'Broken Glassware & Biohazard Disposal',
          'Ventilation & Airborne Contaminant',
        ];

  // Quick preset hazard photo options
  const presetPhotos =
    sector === 'construction'
      ? [
          {
            id: 'scaffold_loose',
            label: 'Scaffolding clamp loose on 4th floor staging',
            color: 'from-amber-700 to-amber-900',
          },
          {
            id: 'cable_water',
            label: 'High voltage electrical cable submerged in rain puddle',
            color: 'from-rose-700 to-slate-900',
          },
          {
            id: 'missing_harness',
            label: 'Worker untethered on edge without static lifeline',
            color: 'from-yellow-600 to-slate-800',
          },
        ]
      : [
          {
            id: 'fume_alarm',
            label: 'Fume hood sensor velocity alarm taped over',
            color: 'from-teal-700 to-slate-900',
          },
          {
            id: 'blocked_exit',
            label: 'Archive examination boxes blocking west fire stairwell',
            color: 'from-amber-800 to-slate-900',
          },
          {
            id: 'wire_snag',
            label: 'Daisy-chained surge protectors under student bench',
            color: 'from-rose-800 to-slate-900',
          },
        ];

  // Voice transcript append handler
  const handleVoiceTranscript = (text: string) => {
    setDescription((prev) => (prev ? `${prev} ${text}` : text));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!category || !title.trim() || !description.trim() || !location.trim()) {
      setValidationError('Please complete all required fields (category, title, description, location).');
      return;
    }
    setValidationError(null);

    const created = addSafetyReport({
      workerId: activeWorker.id,
      sector,
      category,
      title: title.trim(),
      description: description.trim(),
      severity,
      location: location.trim(),
      imageCaption: selectedPresetImage
        ? presetPhotos.find((p) => p.id === selectedPresetImage)?.label
        : imageCaption || undefined,
      voiceRecorded: true,
    });

    setLastSubmittedId(created.id);
    setTitle('');
    setDescription('');
    setLocation('');
    setImageCaption('');
    setSelectedPresetImage(null);
  };

  // Filter reports
  const workerReports = safetyReports.filter(
    (r) => r.sector === sector && (filterStatus === 'all' || r.status === filterStatus)
  );

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            {t.safetyTitle}
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            {t.safetySubtitle} Reports immediately alert site supervisors and trigger inspection timelines.
          </p>
        </div>
        <div className="text-xs text-slate-500 bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
          Protected Worker Rights: No retaliation for safety reports.
        </div>
      </div>

      {/* Success Notification Banner */}
      {lastSubmittedId && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-start justify-between gap-3 animate-in fade-in duration-200">
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-emerald-900">
                {t.reportSubmittedSuccess} <span className="font-mono">{lastSubmittedId}</span>
              </p>
              <p className="text-xs text-emerald-700 mt-0.5">
                Site safety coordinators have been notified. You can track remediation progress below.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setLastSubmittedId(null)}
            className="text-emerald-700 hover:text-emerald-900 text-xs font-semibold"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* 2-Column Split: Form on Left, Tracking Feed on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Form */}
        <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-5">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-600" />
              <h2 className="text-base font-bold text-slate-900">
                {t.reportHazard}
              </h2>
            </div>
            <span className="text-xs text-slate-400 capitalize">{sector} Protocol</span>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {validationError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800">
                {validationError}
              </div>
            )}

            {/* Category */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.hazardCategory} <span className="text-rose-500">*</span>
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-700"
                required
              >
                <option value="">Select a hazard category...</option>
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            {/* Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Short Hazard Summary <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                placeholder={
                  sector === 'construction'
                    ? 'e.g. Loose safety netting on Level 4 scaffolding'
                    : 'e.g. Fume hood ventilation failure during solvent extraction'
                }
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-700"
                required
              />
            </div>

            {/* Severity Level Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.hazardSeverity} <span className="text-rose-500">*</span>
              </label>
              <div className="grid grid-cols-4 gap-2">
                {(['low', 'medium', 'high', 'critical'] as SafetySeverity[]).map((sev) => {
                  const isSelected = severity === sev;
                  const colors = {
                    low: isSelected ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-700 hover:bg-slate-100',
                    medium: isSelected ? 'bg-amber-600 text-white' : 'bg-amber-50 text-amber-800 hover:bg-amber-100',
                    high: isSelected ? 'bg-orange-600 text-white' : 'bg-orange-50 text-orange-800 hover:bg-orange-100',
                    critical: isSelected ? 'bg-rose-700 text-white' : 'bg-rose-50 text-rose-800 hover:bg-rose-100',
                  }[sev];

                  return (
                    <button
                      key={sev}
                      type="button"
                      onClick={() => setSeverity(sev)}
                      className={`py-2 px-1 text-center text-xs font-semibold rounded-lg capitalize transition-colors ${colors}`}
                    >
                      {sev}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Location */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.hazardLocation} <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <MapPin className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder={
                    sector === 'construction'
                      ? 'e.g. SRM Site B Tower - Level 4 North Facade Grid 12'
                      : 'e.g. Tech Park Block 3 - Wet Chemistry Lab 308'
                  }
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-2.5 text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-700"
                  required
                />
              </div>
            </div>

            {/* Description with Voice Dictation */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-700">
                  {t.hazardDescription} <span className="text-rose-500">*</span>
                </label>
                <VoiceInputButton onTranscript={handleVoiceTranscript} />
              </div>
              <textarea
                rows={3}
                placeholder="Explain the specific danger, affected personnel, and immediate risk..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-3 text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-700 leading-relaxed"
                required
              />
              <div className="mt-1 text-[11px] text-slate-400">
                Tip: Voice dictation works in English, Hindi, and Tamil based on your selected language.
              </div>
            </div>

            {/* Photo Attachment / Preset Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t.attachPhoto} (Sample Photo Evidence)
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {presetPhotos.map((preset) => {
                  const isChosen = selectedPresetImage === preset.id;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() =>
                        setSelectedPresetImage(isChosen ? null : preset.id)
                      }
                      className={`p-2.5 rounded-xl border text-left transition-all relative ${
                        isChosen
                          ? 'border-teal-700 bg-teal-50/60 ring-1 ring-teal-600'
                          : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
                      }`}
                    >
                      <div className={`h-12 rounded-lg bg-gradient-to-br ${preset.color} flex items-center justify-center text-white mb-2 shadow-2xs`}>
                        <Camera className="w-5 h-5 opacity-80" />
                      </div>
                      <p className="text-[11px] font-medium text-slate-800 leading-tight">
                        {preset.label}
                      </p>
                      {isChosen && (
                        <div className="absolute top-2 right-2 w-4 h-4 bg-teal-700 rounded-full text-white flex items-center justify-center text-[10px]">
                          <Check className="w-2.5 h-2.5" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-2.5 px-4 text-xs font-bold text-white bg-teal-800 hover:bg-teal-900 rounded-xl transition-colors flex items-center justify-center gap-2 shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{t.submitReport}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Right Column: Tracked Reports List */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="text-sm font-bold text-slate-900">
                {t.myReports} ({workerReports.length})
              </h2>

              {/* Status Filter */}
              <div className="flex items-center gap-1 text-xs">
                {(['all', 'submitted', 'under_review', 'resolved'] as const).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setFilterStatus(st)}
                    className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors capitalize ${
                      filterStatus === st
                        ? 'bg-slate-900 text-white font-semibold'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {st === 'under_review' ? 'Review' : st}
                  </button>
                ))}
              </div>
            </div>

            {/* Reports List */}
            <div className="mt-3 divide-y divide-slate-100 max-h-[580px] overflow-y-auto pr-1 space-y-3">
              {workerReports.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-400">
                  No reports matching this filter.
                </div>
              ) : (
                workerReports.map((report) => {
                  const severityBadge = {
                    low: 'text-slate-600 bg-slate-100',
                    medium: 'text-amber-800 bg-amber-50 border-amber-200',
                    high: 'text-orange-800 bg-orange-50 border-orange-200',
                    critical: 'text-rose-800 bg-rose-50 border-rose-200',
                  }[report.severity];

                  const statusBadge = {
                    submitted: 'text-amber-700 bg-amber-50',
                    under_review: 'text-sky-700 bg-sky-50',
                    resolved: 'text-emerald-700 bg-emerald-50',
                  }[report.status];

                  return (
                    <div key={report.id} className="pt-3 first:pt-0 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2 text-[11px]">
                            <span className="font-mono font-semibold text-slate-900">
                              {report.id}
                            </span>
                            <span className="text-slate-400">·</span>
                            <span className="text-slate-400 font-mono">{report.timestamp}</span>
                          </div>
                          <h4 className="text-xs font-semibold text-slate-900 mt-1">
                            {report.title}
                          </h4>
                        </div>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${severityBadge}`}>
                          {report.severity}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2">
                        {report.description}
                      </p>

                      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                        <span className="truncate max-w-[200px]">📍 {report.location}</span>
                        <span className={`font-semibold px-2 py-0.5 rounded capitalize ${statusBadge}`}>
                          {report.status.replace('_', ' ')}
                        </span>
                      </div>

                      {report.resolutionNote && (
                        <div className="mt-2 p-2.5 bg-emerald-50/70 border border-emerald-200 rounded-lg text-[11px] text-emerald-900">
                          <strong className="block font-semibold">Supervisor Resolution Note:</strong>
                          <p className="mt-0.5">{report.resolutionNote}</p>
                          {report.resolvedAt && (
                            <span className="text-[10px] text-emerald-700 block mt-1 font-mono">
                              Resolved at {report.resolvedAt} by {report.reviewedBy}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
