import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  FileText,
  Printer,
  HelpCircle,
  AlertCircle,
  TrendingUp,
  ShieldAlert,
  Info,
  Calendar,
  IndianRupee
} from 'lucide-react';
import { Language } from '../../types';

export const ClearPayslip: React.FC = () => {
  const {
    t,
    language,
    setLanguage,
    activeWorker,
    sector,
    shifts,
  } = useApp();

  const [activeExplanation, setActiveExplanation] = useState<string | null>(null);

  // Calculate actual hours worked for this worker from shifts
  const workerShifts = shifts.filter((s) => s.workerId === activeWorker.id);
  const totalRegularHours = workerShifts.reduce((acc, s) => acc + s.regularHours, 0) || 40;
  const totalOvertimeHours = workerShifts.reduce((acc, s) => acc + s.overtimeHours, 0) || 8.4;

  const hourlyRate = activeWorker.hourlyRate;
  const baseEarnings = Math.round(totalRegularHours * hourlyRate);
  
  // Overtime rate is 1.5x regular hourly wage
  const overtimeRate = hourlyRate * 1.5;
  const overtimeEarnings = Math.round(totalOvertimeHours * overtimeRate);

  // Sector allowance (Site hardship / lab reagent hazard allowance)
  const specialAllowance = sector === 'construction' ? 1200 : 2500;

  const grossEarnings = baseEarnings + overtimeEarnings + specialAllowance;

  // Statutory deductions
  const providentFund = Math.round(baseEarnings * 0.12); // 12% PF
  const esiHealthcare = Math.round(grossEarnings * 0.0075); // 0.75% ESI
  const professionalTax = 200; // standard slab

  const totalDeductions = providentFund + esiHealthcare + professionalTax;
  const netTakeHome = grossEarnings - totalDeductions;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header & Section Lead */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200 no-print">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            {t.payslipTitle}
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            {t.payslipSubtitle} Multi-language itemized payroll transparency for every logged hour.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3">
          {/* Quick Language Toggle on Payslip */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            {(['en', 'hi', 'ta'] as Language[]).map((lng) => (
              <button
                key={lng}
                type="button"
                onClick={() => setLanguage(lng)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all ${
                  language === lng
                    ? 'bg-white text-teal-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {lng === 'en' ? 'English' : lng === 'hi' ? 'हिंदी' : 'தமிழ்'}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors shadow-xs"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
            <span>{t.printPayslip}</span>
          </button>
        </div>
      </div>

      {/* Illustrative Notice Banner as mandated by prompt */}
      <div className="bg-amber-50/70 border border-amber-200/80 rounded-xl p-3.5 flex items-start gap-3 no-print">
        <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
        <p className="text-xs text-amber-900 leading-relaxed">
          <strong className="font-semibold">Illustrative Sample Notice:</strong> {t.payslipSampleNote}
        </p>
      </div>

      {/* Main Payslip Container (Formatted for both screen & print) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 md:p-8 max-w-4xl mx-auto shadow-xs">
        {/* Printable Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-200 gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-lg bg-teal-800 text-white flex items-center justify-center text-xs font-extrabold">
                FW
              </span>
              <span className="text-lg font-bold text-slate-900">FairWork Transparent Wage Statement</span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Wage Period: <strong className="text-slate-800 font-mono">16 Oct 2026 – 31 Oct 2026</strong> (Bi-Weekly Cycle)
            </p>
          </div>

          <div className="sm:text-right text-xs text-slate-600 space-y-0.5">
            <div>Employee ID: <strong className="font-mono text-slate-900">{activeWorker.id}</strong></div>
            <div>Department: <strong className="text-slate-800">{activeWorker.departmentOrSite}</strong></div>
            <div>Supervisor: <span className="text-slate-600">{activeWorker.supervisor}</span></div>
          </div>
        </div>

        {/* Worker Info Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-4 border-b border-slate-100 text-xs">
          <div>
            <span className="text-slate-400 block">Worker Name</span>
            <span className="font-semibold text-slate-900 text-sm">{activeWorker.name}</span>
          </div>
          <div>
            <span className="text-slate-400 block">Designation / Role</span>
            <span className="font-medium text-slate-800">{activeWorker.role}</span>
          </div>
          <div>
            <span className="text-slate-400 block">Base Hourly Rate</span>
            <span className="font-mono font-semibold text-slate-900">₹{hourlyRate.toFixed(2)}/hr</span>
          </div>
          <div>
            <span className="text-slate-400 block">Overtime Multiplier</span>
            <span className="font-semibold text-emerald-800">1.50× Statutory Premium</span>
          </div>
        </div>

        {/* Earnings & Deductions Split Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 py-6">
          {/* Left Column: Earnings Breakdown */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-teal-700" />
                <span>{t.earningsBreakdown}</span>
              </h3>
              <span className="text-xs text-slate-400">Hours × Rate</span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-slate-800 font-medium">{t.basePay}</span>
                  <span className="block text-[11px] text-slate-400 font-mono">
                    {totalRegularHours.toFixed(1)} hrs @ ₹{hourlyRate}/hr
                  </span>
                </div>
                <span className="font-mono tabular-nums font-semibold text-slate-900">
                  ₹{baseEarnings.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-slate-800 font-medium">{t.overtimeEarnings}</span>
                    <button
                      type="button"
                      onClick={() =>
                        setActiveExplanation(
                          activeExplanation === 'ot' ? null : 'ot'
                        )
                      }
                      className="text-teal-700 hover:text-teal-900 no-print"
                      title={t.howCalculated}
                    >
                      <HelpCircle className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <span className="block text-[11px] text-slate-400 font-mono">
                    {totalOvertimeHours.toFixed(2)} hrs @ ₹{overtimeRate.toFixed(1)}/hr (1.5x)
                  </span>
                </div>
                <span className="font-mono tabular-nums font-semibold text-emerald-700">
                  +₹{overtimeEarnings.toLocaleString('en-IN')}
                </span>
              </div>

              {activeExplanation === 'ot' && (
                <div className="p-2.5 bg-emerald-50 rounded-lg text-[11px] text-emerald-900 border border-emerald-200">
                  <p>{t.otExplanation}</p>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div>
                  <span className="text-slate-800 font-medium">{t.allowance}</span>
                  <span className="block text-[11px] text-slate-400">
                    {sector === 'construction' ? 'Site safety & heat allowance' : 'Lab hazardous reagent handling allowance'}
                  </span>
                </div>
                <span className="font-mono tabular-nums font-semibold text-slate-900">
                  ₹{specialAllowance.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between font-semibold text-slate-900">
                <span>{t.grossPay}</span>
                <span className="font-mono tabular-nums text-sm">
                  ₹{grossEarnings.toLocaleString('en-IN')}
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Statutory Deductions */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-slate-600" />
                <span>{t.deductionsTitle}</span>
              </h3>
              <span className="text-xs text-slate-400">Statutory Govt Rules</span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-slate-800 font-medium">{t.providentFund}</span>
                    <button
                      type="button"
                      onClick={() =>
                        setActiveExplanation(
                          activeExplanation === 'pf' ? null : 'pf'
                        )
                      }
                      className="text-teal-700 hover:text-teal-900 no-print"
                      title={t.howCalculated}
                    >
                      <HelpCircle className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <span className="block text-[11px] text-slate-400">
                    Mandatory Employee Pension Contribution
                  </span>
                </div>
                <span className="font-mono tabular-nums text-slate-700">
                  -₹{providentFund.toLocaleString('en-IN')}
                </span>
              </div>

              {activeExplanation === 'pf' && (
                <div className="p-2.5 bg-slate-50 rounded-lg text-[11px] text-slate-700 border border-slate-200">
                  <p>{t.pfExplanation}</p>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-slate-800 font-medium">{t.esiDeduction}</span>
                    <button
                      type="button"
                      onClick={() =>
                        setActiveExplanation(
                          activeExplanation === 'esi' ? null : 'esi'
                        )
                      }
                      className="text-teal-700 hover:text-teal-900 no-print"
                      title={t.howCalculated}
                    >
                      <HelpCircle className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <span className="block text-[11px] text-slate-400">
                    Medical Insurance Scheme
                  </span>
                </div>
                <span className="font-mono tabular-nums text-slate-700">
                  -₹{esiHealthcare.toLocaleString('en-IN')}
                </span>
              </div>

              {activeExplanation === 'esi' && (
                <div className="p-2.5 bg-slate-50 rounded-lg text-[11px] text-slate-700 border border-slate-200">
                  <p>{t.esiExplanation}</p>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div>
                  <span className="text-slate-800 font-medium">{t.profTax}</span>
                  <span className="block text-[11px] text-slate-400">
                    Tamil Nadu State Professional Slab
                  </span>
                </div>
                <span className="font-mono tabular-nums text-slate-700">
                  -₹{professionalTax.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between font-semibold text-rose-700">
                <span>{t.totalDeductions}</span>
                <span className="font-mono tabular-nums text-sm">
                  -₹{totalDeductions.toLocaleString('en-IN')}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Net Take-Home Highlight Card */}
        <div className="mt-4 p-5 bg-teal-900 text-white rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs text-teal-200 uppercase tracking-wider font-semibold block">
              {t.netPayable}
            </span>
            <p className="text-xs text-teal-100 mt-0.5">
              Net direct bank transfer scheduled for 01 Nov 2026.
            </p>
          </div>
          <div className="text-right">
            <span className="text-3xl font-extrabold font-mono tabular-nums text-emerald-300">
              ₹{netTakeHome.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        {/* Educational Explanations Accordion Footer */}
        <div className="mt-6 pt-4 border-t border-slate-100 text-xs text-slate-500 space-y-2 no-print">
          <div className="flex items-center gap-1.5 font-semibold text-slate-700">
            <Info className="w-4 h-4 text-teal-700" />
            <span>FairWork Transparent Math Guarantee</span>
          </div>
          <p className="leading-relaxed">
            Every minute of overtime is tracked by open formula: <code>Overtime Pay = Hours &gt; 8 × (Base Rate × 1.5)</code>.
            Employers cannot reduce overtime multipliers or round down logged hours.
          </p>
        </div>
      </div>
    </div>
  );
};
