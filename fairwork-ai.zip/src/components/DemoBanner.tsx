import React from 'react';
import { useApp } from '../context/AppContext';
import { HardHat, GraduationCap, RefreshCw, UserCheck, ShieldCheck, Globe } from 'lucide-react';
import { SectorType, UserRole, Language } from '../types';

export const DemoBanner: React.FC = () => {
  const {
    sector,
    setSector,
    role,
    setRole,
    language,
    setLanguage,
    t,
    resetAllDemoData,
    activeWorker,
  } = useApp();

  return (
    <div className="bg-slate-900 text-slate-200 border-b border-slate-800 text-xs py-2 px-4 no-print">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Left: Hackathon Identifier & Active Context */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 font-semibold text-emerald-400 tracking-wide">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>PROMPT WARS 2026</span>
          </div>
          <span className="text-slate-600 hidden sm:inline">|</span>
          <p className="text-slate-400 hidden md:inline">
            <span className="text-slate-300 font-medium">{t.demoBadge}:</span> {t.demoNotice}
          </p>
        </div>

        {/* Right: Quick Sector, Role & Language Switchers */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Sector Switcher */}
          <div className="flex items-center bg-slate-800/90 rounded-md p-0.5 border border-slate-700">
            <button
              type="button"
              onClick={() => setSector('construction')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-all ${
                sector === 'construction'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
              title="Switch to Construction Sector"
            >
              <HardHat className="w-3.5 h-3.5" />
              <span>{t.construction}</span>
            </button>
            <button
              type="button"
              onClick={() => setSector('education')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-all ${
                sector === 'education'
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
              title="Switch to Education Sector"
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span>{t.education}</span>
            </button>
          </div>

          {/* Role Switcher */}
          <div className="flex items-center bg-slate-800/90 rounded-md p-0.5 border border-slate-700">
            <button
              type="button"
              onClick={() => setRole('worker')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-all ${
                role === 'worker'
                  ? 'bg-white text-slate-900 shadow-sm font-semibold'
                  : 'text-slate-300 hover:text-white'
              }`}
              title="Explore Worker Portal"
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>Worker</span>
            </button>
            <button
              type="button"
              onClick={() => setRole('admin')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-all ${
                role === 'admin'
                  ? 'bg-white text-slate-900 shadow-sm font-semibold'
                  : 'text-slate-300 hover:text-white'
              }`}
              title="Explore Admin Dashboard"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin</span>
            </button>
          </div>

          {/* Language Selector */}
          <div className="flex items-center gap-1 bg-slate-800/90 rounded-md px-2 py-1 border border-slate-700">
            <Globe className="w-3 h-3 text-slate-400" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as Language)}
              className="bg-transparent text-slate-200 text-xs font-medium focus:outline-none cursor-pointer"
              aria-label="Select Interface Language"
            >
              <option value="en" className="bg-slate-900 text-white">EN (English)</option>
              <option value="hi" className="bg-slate-900 text-white">HI (हिंदी)</option>
              <option value="ta" className="bg-slate-900 text-white">TA (தமிழ்)</option>
            </select>
          </div>

          {/* Reset Demo Button */}
          <button
            type="button"
            onClick={() => {
              if (window.confirm('Reset all demo records, shifts, and reports to default?')) {
                resetAllDemoData();
              }
            }}
            className="flex items-center gap-1 px-2 py-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Reset All Demo Data"
          >
            <RefreshCw className="w-3 h-3" />
            <span className="hidden lg:inline">Reset Demo</span>
          </button>
        </div>
      </div>
    </div>
  );
};
