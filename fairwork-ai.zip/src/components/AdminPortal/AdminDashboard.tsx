import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  Clock,
  AlertTriangle,
  Activity,
  MessageSquare,
  TrendingDown,
  CheckCircle2,
  Filter,
  ShieldCheck,
  ChevronRight,
  ExternalLink,
  Info,
  Calendar,
  AlertOctagon,
  ArrowUpRight
} from 'lucide-react';
import { SectorType, SafetyStatus } from '../../types';

export const AdminDashboard: React.FC = () => {
  const {
    t,
    sector,
    shifts,
    safetyReports,
    updateSafetyReportStatus,
    feedbackEntries,
    fatigueAlerts,
    availableWorkers,
  } = useApp();

  const [selectedSectorFilter, setSelectedSectorFilter] = useState<'all' | SectorType>('all');
  const [dateRange, setDateRange] = useState<'7d' | '30d'>('7d');
  const [resolutionNoteInput, setResolutionNoteInput] = useState<{ [id: string]: string }>({});
  const [activeHazardTab, setActiveHazardTab] = useState<'open' | 'resolved'>('open');

  // Filter datasets by selected sector
  const filteredReports = safetyReports.filter(
    (r) => selectedSectorFilter === 'all' || r.sector === selectedSectorFilter
  );

  const filteredAlerts = fatigueAlerts.filter(
    (a) => selectedSectorFilter === 'all' || a.sector === selectedSectorFilter
  );

  const filteredFeedback = feedbackEntries.filter(
    (f) => selectedSectorFilter === 'all' || f.sector === selectedSectorFilter
  );

  const filteredShifts = shifts.filter(
    (s) => selectedSectorFilter === 'all' || s.sector === selectedSectorFilter
  );

  // Compute Aggregate KPIs
  const totalLoggedHours = filteredShifts.reduce((acc, s) => acc + s.regularHours + s.overtimeHours, 0);
  const totalOvertimeHours = filteredShifts.reduce((acc, s) => acc + s.overtimeHours, 0);
  const openHazardsCount = filteredReports.filter((r) => r.status !== 'resolved').length;
  const criticalHazardsCount = filteredReports.filter((r) => r.severity === 'critical' && r.status !== 'resolved').length;
  const avgFeedbackRating = filteredFeedback.length
    ? (filteredFeedback.reduce((acc, f) => acc + f.rating, 0) / filteredFeedback.length).toFixed(1)
    : '4.0';

  // Interactive Chart Data: 7-day Attendance and Overtime Trend
  const chartDays = [
    { day: 'Mon 20', date: '2026-10-20', regular: 38, overtime: 6 },
    { day: 'Tue 21', date: '2026-10-21', regular: 42, overtime: 8 },
    { day: 'Wed 22', date: '2026-10-22', regular: 40, overtime: 5 },
    { day: 'Thu 23', date: '2026-10-23', regular: 46, overtime: 12 },
    { day: 'Fri 24', date: '2026-10-24', regular: 48, overtime: 16 },
    { day: 'Sat 25', date: '2026-10-25', regular: 44, overtime: 14 },
    { day: 'Sun 26', date: '2026-10-26', regular: 24, overtime: 4 },
  ];

  // Severity Breakdown
  const severityCounts = {
    critical: filteredReports.filter((r) => r.severity === 'critical').length,
    high: filteredReports.filter((r) => r.severity === 'high').length,
    medium: filteredReports.filter((r) => r.severity === 'medium').length,
    low: filteredReports.filter((r) => r.severity === 'low').length,
  };

  const handleResolveHazard = (id: string) => {
    const note = resolutionNoteInput[id] || 'Remediation completed and verified by site safety inspector.';
    updateSafetyReportStatus(id, 'resolved', note);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Filters */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            {t.adminTitle}
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            {t.adminSubtitle} Real-time operational visibility across safety compliance, overtime workloads, and worker sentiment.
          </p>
        </div>

        {/* Sector and Date Filter Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Sector Filter */}
          <div className="flex items-center bg-white border border-slate-200 rounded-xl p-1 text-xs">
            <span className="text-slate-400 px-2 flex items-center gap-1 font-medium">
              <Filter className="w-3 h-3" />
              <span>Sector:</span>
            </span>
            <button
              type="button"
              onClick={() => setSelectedSectorFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                selectedSectorFilter === 'all'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All
            </button>
            <button
              type="button"
              onClick={() => setSelectedSectorFilter('construction')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                selectedSectorFilter === 'construction'
                  ? 'bg-emerald-700 text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Construction
            </button>
            <button
              type="button"
              onClick={() => setSelectedSectorFilter('education')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                selectedSectorFilter === 'education'
                  ? 'bg-teal-700 text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Education
            </button>
          </div>

          {/* Date Range Toggle */}
          <div className="flex items-center bg-white border border-slate-200 rounded-xl p-1 text-xs">
            <button
              type="button"
              onClick={() => setDateRange('7d')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                dateRange === '7d' ? 'bg-slate-100 text-slate-900 font-semibold' : 'text-slate-500'
              }`}
            >
              Last 7 Days
            </button>
            <button
              type="button"
              onClick={() => setDateRange('30d')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                dateRange === '30d' ? 'bg-slate-100 text-slate-900 font-semibold' : 'text-slate-500'
              }`}
            >
              30 Days
            </button>
          </div>
        </div>
      </div>

      {/* KPI Overview Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>{t.kpiWorkers}</span>
            <Users className="w-4 h-4 text-teal-700" />
          </div>
          <p className="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-900">
            {selectedSectorFilter === 'all' ? 142 : selectedSectorFilter === 'construction' ? 88 : 54}
          </p>
          <span className="text-[11px] text-slate-400 mt-1 block">Active on roster</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>{t.kpiHours}</span>
            <Clock className="w-4 h-4 text-teal-700" />
          </div>
          <p className="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-900">
            {totalLoggedHours.toFixed(0)} <span className="text-xs font-normal text-slate-500">hrs</span>
          </p>
          <span className="text-[11px] text-amber-700 mt-1 block">
            +{totalOvertimeHours.toFixed(1)}h overtime
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>{t.kpiHazards}</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <p className="mt-2 text-2xl font-bold font-mono tabular-nums text-rose-700">
            {openHazardsCount}
          </p>
          <span className="text-[11px] text-rose-600 font-medium mt-1 block">
            {criticalHazardsCount} Critical Urgency
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>{t.kpiFatigue}</span>
            <Activity className="w-4 h-4 text-orange-600" />
          </div>
          <p className="mt-2 text-2xl font-bold font-mono tabular-nums text-orange-700">
            {filteredAlerts.length}
          </p>
          <span className="text-[11px] text-slate-400 mt-1 block">Exceeded shift limits</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 col-span-2 lg:col-span-1">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>{t.kpiFeedback}</span>
            <MessageSquare className="w-4 h-4 text-teal-700" />
          </div>
          <p className="mt-2 text-2xl font-bold font-mono tabular-nums text-slate-900">
            {avgFeedbackRating} <span className="text-xs font-normal text-slate-400">/ 5.0</span>
          </p>
          <span className="text-[11px] text-emerald-700 mt-1 block">
            {filteredFeedback.length} confidential reviews
          </span>
        </div>
      </div>

      {/* Visual Analytics Grid: SVG Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* 7-Day Attendance & Overtime SVG Trend Chart */}
        <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Workforce Attendance & Overtime Volume
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Daily cumulative hours logged across regular shifts vs overtime spikes.
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs font-medium">
              <span className="flex items-center gap-1.5 text-slate-600">
                <span className="w-3 h-3 bg-teal-800 rounded-sm"></span>
                <span>Regular (8h Base)</span>
              </span>
              <span className="flex items-center gap-1.5 text-amber-700">
                <span className="w-3 h-3 bg-amber-500 rounded-sm"></span>
                <span>Overtime (1.5x)</span>
              </span>
            </div>
          </div>

          {/* SVG Bar Chart */}
          <div className="mt-6">
            <div className="h-56 w-full flex items-end justify-between gap-2 sm:gap-4 pt-6 pb-2 px-2 border-b border-slate-200">
              {chartDays.map((item) => {
                const maxVal = 70; // max scale
                const regularHeightPercent = (item.regular / maxVal) * 100;
                const overtimeHeightPercent = (item.overtime / maxVal) * 100;

                return (
                  <div key={item.day} className="flex-1 flex flex-col items-center gap-1.5 group relative">
                    {/* Tooltip on Hover */}
                    <div className="absolute -top-12 bg-slate-900 text-white text-[10px] py-1 px-2 rounded pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10 font-mono">
                      {item.regular}h regular + {item.overtime}h OT
                    </div>

                    {/* Stacked Bars */}
                    <div className="w-full max-w-[48px] flex flex-col justify-end h-44 rounded-t-sm overflow-hidden bg-slate-50">
                      <div
                        style={{ height: `${overtimeHeightPercent}%` }}
                        className="bg-amber-500 w-full transition-all group-hover:bg-amber-400"
                        title={`${item.overtime}h Overtime`}
                      ></div>
                      <div
                        style={{ height: `${regularHeightPercent}%` }}
                        className="bg-teal-800 w-full transition-all group-hover:bg-teal-700"
                        title={`${item.regular}h Standard`}
                      ></div>
                    </div>

                    <span className="text-[11px] font-mono tabular-nums text-slate-600">
                      {item.day.split(' ')[0]}
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="flex justify-between items-center text-[11px] text-slate-400 pt-2 px-2">
              <span>0h Baseline</span>
              <span>35h Normal</span>
              <span>70h Max Capacity Threshold</span>
            </div>
          </div>
        </div>

        {/* Safety Severity & Feedback Themes Widget */}
        <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
          <div>
            <h2 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
              Hazard Distribution by Severity
            </h2>
            <div className="mt-4 space-y-3 text-xs">
              <div>
                <div className="flex justify-between text-slate-700 font-medium mb-1">
                  <span className="flex items-center gap-1.5 text-rose-700 font-semibold">
                    <span className="w-2 h-2 rounded-full bg-rose-600"></span>
                    Critical (Work Stoppage)
                  </span>
                  <span className="font-mono tabular-nums font-bold">{severityCounts.critical}</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${(severityCounts.critical / (filteredReports.length || 1)) * 100}%` }}
                    className="bg-rose-600 h-full rounded-full"
                  ></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-700 font-medium mb-1">
                  <span className="flex items-center gap-1.5 text-orange-700 font-semibold">
                    <span className="w-2 h-2 rounded-full bg-orange-500"></span>
                    High Urgency
                  </span>
                  <span className="font-mono tabular-nums font-bold">{severityCounts.high}</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${(severityCounts.high / (filteredReports.length || 1)) * 100}%` }}
                    className="bg-orange-500 h-full rounded-full"
                  ></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-700 font-medium mb-1">
                  <span className="flex items-center gap-1.5 text-amber-700">
                    <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                    Medium (Maintenance)
                  </span>
                  <span className="font-mono tabular-nums font-bold">{severityCounts.medium}</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${(severityCounts.medium / (filteredReports.length || 1)) * 100}%` }}
                    className="bg-amber-400 h-full rounded-full"
                  ></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-700 font-medium mb-1">
                  <span className="flex items-center gap-1.5 text-slate-600">
                    <span className="w-2 h-2 rounded-full bg-slate-400"></span>
                    Low (Observation)
                  </span>
                  <span className="font-mono tabular-nums font-bold">{severityCounts.low}</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${(severityCounts.low / (filteredReports.length || 1)) * 100}%` }}
                    className="bg-slate-400 h-full rounded-full"
                  ></div>
                </div>
              </div>
            </div>
          </div>

          {/* Feedback Themes Breakdown */}
          <div className="pt-4 border-t border-slate-100">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
              Recent Feedback Sentiment
            </h3>
            <div className="p-3 bg-slate-50 rounded-xl text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-600">Positive Experiences:</span>
                <span className="font-mono font-semibold text-emerald-700">
                  {filteredFeedback.filter((f) => f.sentiment === 'positive').length}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Neutral Observations:</span>
                <span className="font-mono font-semibold text-slate-700">
                  {filteredFeedback.filter((f) => f.sentiment === 'neutral').length}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Workload / Facility Concerns:</span>
                <span className="font-mono font-semibold text-amber-700">
                  {filteredFeedback.filter((f) => f.sentiment === 'concern').length}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Experimental Retention-Risk Indicator with Mandatory Disclaimer */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-teal-800" />
            <h2 className="text-base font-bold text-slate-900">
              {t.retentionTitle}
            </h2>
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
              Experimental Heuristic
            </span>
          </div>
          <span className="text-xs text-slate-400 font-mono">Sample Algorithmic Model v0.4</span>
        </div>

        {/* Clear Disclaimer as requested by prompt:
            "Never present a prediction of employee resignation as a proven fact.
             If a retention-risk indicator is included, label it experimental and explain its limitations." */}
        <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-4 text-xs text-amber-900 flex items-start gap-3">
          <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <strong className="block font-semibold">Important Methodology & Limitations Notice:</strong>
            <p className="leading-relaxed">
              {t.retentionDisclaimer} This score is an experimental computational index combining repeated weekly overtime spikes (&gt;12h/week), consecutive shift fatigue alerts, and low survey sentiment ratings. It does NOT predict individual intentions or resignation decisions and must never be used for disciplinary actions or termination.
            </p>
          </div>
        </div>

        {/* Experimental Indicator Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-800">
                SRM Foundation Rebar Crew
              </span>
              <span className="text-[11px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                Moderate Fatigue
              </span>
            </div>
            <p className="mt-2 text-xs text-slate-600 leading-relaxed">
              3 workers logged 6 consecutive 9.5-hour shifts during foundation concrete pour. High cumulative physical strain.
            </p>
            <div className="mt-3 text-[11px] text-teal-800 font-medium">
              Suggested: Allocate substitute crew for Monday shift.
            </div>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-800">
                Examination & Evaluation Pool
              </span>
              <span className="text-[11px] font-bold text-orange-800 bg-orange-100 px-2 py-0.5 rounded">
                Workload Strain
              </span>
            </div>
            <p className="mt-2 text-xs text-slate-600 leading-relaxed">
              Faculty feedback indicates 48h turnaround deadline for 180 answer sheets coinciding with full lecture load.
            </p>
            <div className="mt-3 text-[11px] text-teal-800 font-medium">
              Suggested: Grant 24h deadline extension or assign TAs.
            </div>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-800">
                Tower Crane & Rigging Team
              </span>
              <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                Optimal Rest
              </span>
            </div>
            <p className="mt-2 text-xs text-slate-600 leading-relaxed">
              Turnaround intervals average 13.5 hours between shifts. Zero back-to-back night lifts this week.
            </p>
            <div className="mt-3 text-[11px] text-emerald-800 font-medium">
              Status: Operating within safe circadian parameters.
            </div>
          </div>
        </div>
      </div>

      {/* Prioritized Manager Action Queue & Safety Hazard Resolution */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              {t.actionListTitle}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Urgent tasks ordered by severity, hazard level, and fatigue risk.
            </p>
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-medium">
            <button
              type="button"
              onClick={() => setActiveHazardTab('open')}
              className={`px-3 py-1 rounded-lg transition-colors ${
                activeHazardTab === 'open'
                  ? 'bg-white text-slate-900 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Open Hazards ({filteredReports.filter((r) => r.status !== 'resolved').length})
            </button>
            <button
              type="button"
              onClick={() => setActiveHazardTab('resolved')}
              className={`px-3 py-1 rounded-lg transition-colors ${
                activeHazardTab === 'resolved'
                  ? 'bg-white text-slate-900 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Resolved History ({filteredReports.filter((r) => r.status === 'resolved').length})
            </button>
          </div>
        </div>

        {/* Hazard List with Inline Manager Resolution Controls */}
        <div className="divide-y divide-slate-100 space-y-4">
          {filteredReports
            .filter((r) => (activeHazardTab === 'open' ? r.status !== 'resolved' : r.status === 'resolved'))
            .map((report) => {
              const isResolved = report.status === 'resolved';
              return (
                <div key={report.id} className="pt-4 first:pt-0 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-mono font-bold text-slate-900">{report.id}</span>
                        <span className="text-slate-400">·</span>
                        <span className="text-slate-500 capitalize">{report.sector}</span>
                        <span className="text-slate-400">·</span>
                        <span className="font-mono text-slate-400">{report.timestamp}</span>
                      </div>
                      <h4 className="text-sm font-bold text-slate-900 mt-1">
                        {report.title}
                      </h4>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                        report.severity === 'critical'
                          ? 'bg-rose-100 text-rose-800'
                          : report.severity === 'high'
                          ? 'bg-orange-100 text-orange-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {report.severity}
                      </span>
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded capitalize ${
                        isResolved ? 'bg-emerald-100 text-emerald-800' : 'bg-sky-100 text-sky-800'
                      }`}>
                        {report.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {report.description}
                  </p>

                  <div className="text-[11px] text-slate-500 flex items-center gap-2">
                    <span>📍 Location: <strong className="text-slate-700">{report.location}</strong></span>
                    {report.imageCaption && (
                      <>
                        <span>·</span>
                        <span className="italic text-slate-600">Evidence: {report.imageCaption}</span>
                      </>
                    )}
                  </div>

                  {/* Inline Manager Remediation Action */}
                  {!isResolved ? (
                    <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-center gap-2">
                      <input
                        type="text"
                        placeholder="Add manager action note (e.g. Scaffolding crew dispatched and inspected)..."
                        value={resolutionNoteInput[report.id] || ''}
                        onChange={(e) =>
                          setResolutionNoteInput({
                            ...resolutionNoteInput,
                            [report.id]: e.target.value,
                          })
                        }
                        className="w-full text-xs bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-slate-800"
                      />
                      <button
                        type="button"
                        onClick={() => handleResolveHazard(report.id)}
                        className="whitespace-nowrap px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors flex items-center gap-1 shadow-2xs"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{t.resolveAction}</span>
                      </button>
                    </div>
                  ) : (
                    <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs text-emerald-900">
                      <strong>Remediation Verified:</strong> {report.resolutionNote}
                      {report.resolvedAt && (
                        <span className="block text-[11px] text-emerald-700 mt-0.5 font-mono">
                          Resolved {report.resolvedAt} by {report.reviewedBy}
                        </span>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
};
