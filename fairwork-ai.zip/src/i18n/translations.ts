import { Language } from '../types';

export interface TranslationDictionary {
  appName: string;
  tagline: string;
  demoBadge: string;
  demoNotice: string;
  switchSector: string;
  construction: string;
  education: string;
  workerRole: string;
  adminRole: string;
  roleSwitcher: string;
  
  // Navigation
  navShifts: string;
  navPayslip: string;
  navSafety: string;
  navFeedback: string;
  navSkills: string;
  navFatigue: string;
  navAdmin: string;

  // Shift Tracking
  shiftsTitle: string;
  shiftsSubtitle: string;
  checkIn: string;
  checkOut: string;
  checkedInState: string;
  checkedOutState: string;
  simulateQR: string;
  qrModalTitle: string;
  qrDisclaimer: string;
  scanNow: string;
  close: string;
  weeklyHours: string;
  regularHours: string;
  overtimeHours: string;
  attendanceRate: string;

  // Clear Payslips
  payslipTitle: string;
  payslipSubtitle: string;
  payslipSampleNote: string;
  earningsBreakdown: string;
  basePay: string;
  overtimeEarnings: string;
  allowance: string;
  grossPay: string;
  deductionsTitle: string;
  providentFund: string;
  esiDeduction: string;
  profTax: string;
  totalDeductions: string;
  netPayable: string;
  howCalculated: string;
  printPayslip: string;
  pfExplanation: string;
  otExplanation: string;
  esiExplanation: string;

  // Safety Reporting
  safetyTitle: string;
  safetySubtitle: string;
  reportHazard: string;
  hazardCategory: string;
  hazardDescription: string;
  hazardSeverity: string;
  hazardLocation: string;
  attachPhoto: string;
  voiceDictation: string;
  submitReport: string;
  reportSubmittedSuccess: string;
  statusSubmitted: string;
  statusUnderReview: string;
  statusResolved: string;
  myReports: string;
  reportId: string;

  // Honest Feedback
  feedbackTitle: string;
  feedbackSubtitle: string;
  feedbackTopic: string;
  feedbackMessage: string;
  feedbackNoticeTitle: string;
  feedbackNoticeBody: string;
  submitFeedback: string;
  feedbackSuccess: string;
  ratingLabel: string;

  // Skill Passport
  passportTitle: string;
  passportSubtitle: string;
  verifiedCredential: string;
  selfReported: string;
  addRecord: string;
  downloadSummary: string;
  trainingHours: string;
  certNumber: string;

  // Fatigue
  fatigueTitle: string;
  fatigueSubtitle: string;
  fatigueDisclaimer: string;
  thresholdsTitle: string;
  maxDailyHours: string;
  minRestBetweenShifts: string;
  maxConsecutiveDays: string;
  statusNormal: string;
  statusWarning: string;

  // Admin
  adminTitle: string;
  adminSubtitle: string;
  kpiWorkers: string;
  kpiHours: string;
  kpiHazards: string;
  kpiFatigue: string;
  kpiFeedback: string;
  retentionTitle: string;
  retentionDisclaimer: string;
  actionListTitle: string;
  resolveAction: string;
  filterSector: string;
  allSectors: string;
}

export const translations: Record<Language, TranslationDictionary> = {
  en: {
    appName: 'FairWork AI',
    tagline: 'Transparent shifts, fair pay, and workforce health',
    demoBadge: 'Hackathon Demo Mode',
    demoNotice: 'Interactive prototype with persistent local state. QR check-in & payslips are simulated for demonstration.',
    switchSector: 'Switch Industry',
    construction: 'Construction',
    education: 'Education',
    workerRole: 'Worker Portal',
    adminRole: 'Admin Console',
    roleSwitcher: 'Switch Role',

    navShifts: 'Shift Tracker',
    navPayslip: 'Clear Payslip',
    navSafety: 'Safety Reporting',
    navFeedback: 'Honest Feedback',
    navSkills: 'Skill Passport',
    navFatigue: 'Fatigue Alerts',
    navAdmin: 'Admin Dashboard',

    shiftsTitle: 'Shift Schedule & Attendance',
    shiftsSubtitle: 'Track your scheduled shifts, log check-in times, and monitor overtime transparently.',
    checkIn: 'Clock In',
    checkOut: 'Clock Out',
    checkedInState: 'Currently On Shift',
    checkedOutState: 'Currently Off Shift',
    simulateQR: 'Simulate QR Check-In',
    qrModalTitle: 'Site Attendance QR Scanner',
    qrDisclaimer: 'Simulated QR check-in: Demonstrates instant optical token attendance without collecting or requiring real GPS hardware location.',
    scanNow: 'Simulate Instant QR Scan',
    close: 'Close',
    weeklyHours: 'Weekly Hours',
    regularHours: 'Standard Hours',
    overtimeHours: 'Overtime Hours',
    attendanceRate: 'Punctuality Rate',

    payslipTitle: 'Clear Transparent Payslip',
    payslipSubtitle: 'Clear itemized breakdown of base wages, overtime formulas, and statutory deductions.',
    payslipSampleNote: 'Illustrative Sample Payslip — Built to clarify earnings math. Not an official bank tax or legal document.',
    earningsBreakdown: 'Earnings Breakdown',
    basePay: 'Base Wages',
    overtimeEarnings: 'Overtime Pay (1.5x Rate)',
    allowance: 'Site & Special Allowance',
    grossPay: 'Gross Total Earnings',
    deductionsTitle: 'Statutory Deductions',
    providentFund: 'Provident Fund (PF - 12%)',
    esiDeduction: 'ESI / Medical Scheme (0.75%)',
    profTax: 'Professional Tax',
    totalDeductions: 'Total Deductions',
    netPayable: 'Estimated Net Take-Home Pay',
    howCalculated: 'How is this calculated?',
    printPayslip: 'Print / Save Payslip',
    pfExplanation: 'Provident Fund (PF) is 12% of basic pay, matched by employer into your retirement pension reserve.',
    otExplanation: 'Overtime is paid at 1.5x your standard hourly wage for all hours worked beyond 8 hours per shift.',
    esiExplanation: 'Employees State Insurance (ESI) provides cashless outpatient and emergency healthcare coverage for you and family.',

    safetyTitle: 'Workplace Hazard & Safety Reporting',
    safetySubtitle: 'Raise hazards confidentially with severity tracking, photo evidence, and status updates.',
    reportHazard: 'Report a Hazard',
    hazardCategory: 'Hazard Category',
    hazardDescription: 'Describe the risk & exact location',
    hazardSeverity: 'Severity Level',
    hazardLocation: 'Workplace Area / Zone',
    attachPhoto: 'Attach Photo Evidence',
    voiceDictation: 'Use Voice Dictation',
    submitReport: 'Submit Safety Report',
    reportSubmittedSuccess: 'Safety report registered successfully! Assigned tracking ID:',
    statusSubmitted: 'Submitted',
    statusUnderReview: 'Under Review',
    statusResolved: 'Resolved',
    myReports: 'Tracked Hazard Reports',
    reportId: 'Report ID',

    feedbackTitle: 'Honest & Confidential Feedback',
    feedbackSubtitle: 'Voice your perspective on management, workload, facilities, and supervisor communication.',
    feedbackTopic: 'Feedback Category',
    feedbackMessage: 'Your confidential perspective',
    feedbackNoticeTitle: 'Confidentiality vs. Technical Anonymity',
    feedbackNoticeBody: 'This report is stored without exposing your name or badge number on the supervisor dashboard. However, it operates in the FairWork AI application database and does not use cryptographic zero-knowledge or Tor network anonymity.',
    submitFeedback: 'Submit Confidential Feedback',
    feedbackSuccess: 'Thank you. Your feedback has been safely recorded for leadership review.',
    ratingLabel: 'Workplace Climate Rating',

    passportTitle: 'Digital Skill Passport',
    passportSubtitle: 'Your portable record of certified safety trainings, site qualifications, and verified competencies.',
    verifiedCredential: 'Verified Credential',
    selfReported: 'Self-Reported Record',
    addRecord: 'Add Training / Skill',
    downloadSummary: 'Print Skills Summary',
    trainingHours: 'Hours Completed',
    certNumber: 'Credential ID',

    fatigueTitle: 'Workload & Fatigue Monitoring',
    fatigueSubtitle: 'Algorithmic checks flag excessive hours and short turnaround intervals before risks emerge.',
    fatigueDisclaimer: 'Notice: Algorithmic workload threshold alert only. Not a medical or clinical diagnosis.',
    thresholdsTitle: 'Active Safety Thresholds',
    maxDailyHours: 'Maximum Daily Shift',
    minRestBetweenShifts: 'Minimum Rest Turnaround',
    maxConsecutiveDays: 'Max Consecutive Days',
    statusNormal: 'Within Safe Rest Thresholds',
    statusWarning: 'Workload Fatigue Advisory Active',

    adminTitle: 'Workforce Health & Operations Console',
    adminSubtitle: 'Enterprise overview of attendance, overtime trends, open safety hazards, and worker sentiment.',
    kpiWorkers: 'Active Personnel',
    kpiHours: 'Hours Logged (Week)',
    kpiHazards: 'Open Safety Hazards',
    kpiFatigue: 'Fatigue Alerts Active',
    kpiFeedback: 'Feedback Sentiment Score',
    retentionTitle: 'Experimental Retention-Risk Indicator',
    retentionDisclaimer: 'Experimental Metric: This indicator evaluates excessive consecutive overtime and feedback dips. It is NOT a proven prediction of employee departure.',
    actionListTitle: 'Prioritized Manager Action Queue',
    resolveAction: 'Mark Resolved',
    filterSector: 'Filter Sector',
    allSectors: 'All Sectors'
  },
  hi: {
    appName: 'FairWork AI',
    tagline: 'पारदर्शी शिफ्ट, उचित वेतन और कार्यबल स्वास्थ्य',
    demoBadge: 'हैकथॉन डेमो मोड',
    demoNotice: 'इंटरैक्टिव प्रोटोटाइप। क्यूआर चेक-इन और पेस्लिप प्रदर्शन के लिए सिम्युलेटेड हैं।',
    switchSector: 'उद्योग बदलें',
    construction: 'निर्माण (Construction)',
    education: 'शिक्षा (Education)',
    workerRole: 'श्रमिक पोर्टल',
    adminRole: 'प्रशासक डैशबोर्ड',
    roleSwitcher: 'भूमिका बदलें',

    navShifts: 'शिफ्ट ट्रैकर',
    navPayslip: 'स्पष्ट पेस्लिप',
    navSafety: 'सुरक्षा रिपोर्ट',
    navFeedback: 'गोपनीय सुझाव',
    navSkills: 'स्किल पासपोर्ट',
    navFatigue: 'थकान अलर्ट',
    navAdmin: 'एडमिन कंसोल',

    shiftsTitle: 'शिफ्ट अनुसूची और उपस्थिति',
    shiftsSubtitle: 'अपनी शिफ्ट देखें, चेक-इन समय दर्ज करें और ओवरटाइम को स्पष्ट रूप से ट्रैक करें।',
    checkIn: 'चेक इन करें',
    checkOut: 'चेक आउट करें',
    checkedInState: 'वर्तमान में ड्यूटी पर',
    checkedOutState: 'वर्तमान में ड्यूटी समाप्त',
    simulateQR: 'सिम्युलेटेड क्यूआर चेक-इन',
    qrModalTitle: 'साइट उपस्थिति क्यूआर स्कैनर',
    qrDisclaimer: 'सिम्युलेटेड क्यूआर: वास्तविक जीपीएस लोकेशन के बिना त्वरित उपस्थिति प्रक्रिया को दर्शाता है।',
    scanNow: 'त्वरित स्कैन पूरा करें',
    close: 'बंद करें',
    weeklyHours: 'साप्ताहिक घंटे',
    regularHours: 'मानक घंटे',
    overtimeHours: 'ओवरटाइम घंटे',
    attendanceRate: 'समयबद्धता दर',

    payslipTitle: 'पारदर्शी वेतन पर्ची (पेस्लिप)',
    payslipSubtitle: 'मूल वेतन, ओवरटाइम गणना और सरकारी कटौतियों का स्पष्ट विवरण।',
    payslipSampleNote: 'उदाहरणात्मक नमूना पेस्लिप — कमाई की गणना समझाने के लिए। कोई आधिकारिक कर दस्तावेज नहीं।',
    earningsBreakdown: 'आय का विवरण',
    basePay: 'मूल वेतन',
    overtimeEarnings: 'ओवरटाइम आय (1.5x दर)',
    allowance: 'साइट और विशेष भत्ता',
    grossPay: 'सकल कुल आय',
    deductionsTitle: 'वैधानिक कटौतियां',
    providentFund: 'भविष्य निधि (PF - 12%)',
    esiDeduction: 'ईएसआई / स्वास्थ्य बीमा (0.75%)',
    profTax: 'व्यावसायिक कर',
    totalDeductions: 'कुल कटौती',
    netPayable: 'अनुमानित शुद्ध इन-हैंड वेतन',
    howCalculated: 'इसकी गणना कैसे की गई है?',
    printPayslip: 'पेस्लिप प्रिंट / सेव करें',
    pfExplanation: 'पीएफ मूल वेतन का 12% होता है, जिसमें नियोक्ता भी समान अंशदान आपके भविष्य कोष में जमा करता है।',
    otExplanation: '8 घंटे से अधिक काम करने पर प्रत्येक घंटे के लिए 1.5 गुना अधिक दर से ओवरटाइम दिया जाता है।',
    esiExplanation: 'ईएसआई आपको और आपके परिवार को कैशलेस अस्पताल और चिकित्सा देखभाल की सुविधा देता है।',

    safetyTitle: 'कार्यस्थल खतरा और सुरक्षा रिपोर्टिंग',
    safetySubtitle: 'गंभीरता ट्रैकिंग, फोटो और स्टेटस अपडेट के साथ खतरों की रिपोर्ट करें।',
    reportHazard: 'खतरे की सूचना दें',
    hazardCategory: 'खतरे की श्रेणी',
    hazardDescription: 'जोखिम और सटीक स्थान का विवरण',
    hazardSeverity: 'गंभीरता स्तर',
    hazardLocation: 'कार्यस्थल क्षेत्र / कक्ष',
    attachPhoto: 'फोटो साक्ष्य जोड़ें',
    voiceDictation: 'बोलकर लिखें (वॉइस इनपुट)',
    submitReport: 'सुरक्षा रिपोर्ट दर्ज करें',
    reportSubmittedSuccess: 'सुरक्षा रिपोर्ट सफलतापूर्वक दर्ज हुई! ट्रैकिंग आईडी:',
    statusSubmitted: 'जमा की गई',
    statusUnderReview: 'समीक्षाधीन',
    statusResolved: 'निराकरण हो गया',
    myReports: 'मेरी दर्ज सुरक्षा रिपोर्टें',
    reportId: 'रिपोर्ट आईडी',

    feedbackTitle: 'ईमानदार और गोपनीय प्रतिक्रिया',
    feedbackSubtitle: 'प्रबंधन, कार्यभार, सुविधाओं और संचार पर अपनी राय साझा करें।',
    feedbackTopic: 'प्रतिक्रिया श्रेणी',
    feedbackMessage: 'आपका गोपनीय संदेश',
    feedbackNoticeTitle: 'गोपनीयता बनाम तकनीकी अज्ञातता',
    feedbackNoticeBody: 'यह रिपोर्ट सुपरवाइजर स्क्रीन पर आपका नाम या बैज नंबर दिखाए बिना सहेजी जाती है। यह क्रिप्टोग्राफिक अज्ञातता (जैसे टोर नेटवर्क) का दावा नहीं करता है।',
    submitFeedback: 'गोपनीय फीडबैक भेजें',
    feedbackSuccess: 'धन्यवाद। आपका सुझाव प्रबंधन समीक्षा के लिए सुरक्षित दर्ज हो गया है।',
    ratingLabel: 'कार्यस्थल अनुभव रेटिंग',

    passportTitle: 'डिजिटल कौशल पासपोर्ट',
    passportSubtitle: 'प्रमाणित सुरक्षा प्रशिक्षण, योग्यता और सत्यापन का आपका स्थायी रिकॉर्ड।',
    verifiedCredential: 'सत्यापित प्रमाणपत्र',
    selfReported: 'स्वयं-घोषित योग्यता',
    addRecord: 'नया प्रशिक्षण / कौशल जोड़ें',
    downloadSummary: 'कौशल सारांश प्रिंट करें',
    trainingHours: 'प्रशिक्षण घंटे',
    certNumber: 'प्रमाणपत्र संख्या',

    fatigueTitle: 'कार्यभार और थकान चेतावनी',
    fatigueSubtitle: 'अत्यधिक घंटे और कम आराम के अंतराल को जोखिम से पहले पहचानना।',
    fatigueDisclaimer: 'सूचना: केवल कार्यभार नियम आधारित संकेत। यह कोई चिकित्सीय निदान नहीं है।',
    thresholdsTitle: 'सक्रिय सुरक्षा सीमाएं',
    maxDailyHours: 'अधिकतम दैनिक शिफ्ट',
    minRestBetweenShifts: 'शिफ्टों के बीच न्यूनतम आराम',
    maxConsecutiveDays: 'लगातार कार्य दिवस',
    statusNormal: 'सुरक्षित सीमा के भीतर',
    statusWarning: 'थकान चेतावनी सक्रिय',

    adminTitle: 'कार्यबल स्वास्थ्य और संचालन कंसोल',
    adminSubtitle: 'उपस्थिति, ओवरटाइम रुझान, खुले सुरक्षा खतरों और समग्र स्थिति का विस्तृत अवलोकन।',
    kpiWorkers: 'सक्रिय कर्मी',
    kpiHours: 'कुल दर्ज घंटे',
    kpiHazards: 'अनसुलझे खतरे',
    kpiFatigue: 'सक्रिय थकान अलर्ट',
    kpiFeedback: 'प्रतिक्रिया स्कोर',
    retentionTitle: 'प्रायोगिक प्रतिधारण जोखिम सूचक',
    retentionDisclaimer: 'प्रायोगिक सूचक: यह अत्यधिक ओवरटाइम और फीडबैक के आधार पर है। यह नौकरी छोड़ने की निश्चित भविष्यवाणी नहीं है।',
    actionListTitle: 'प्राथमिकता वाली कार्य सूची',
    resolveAction: 'हल किया गया चिह्नित करें',
    filterSector: 'उद्योग फ़िल्टर',
    allSectors: 'सभी उद्योग'
  },
  ta: {
    appName: 'FairWork AI',
    tagline: 'வெளிப்படையான பணி நேரம், நியாயமான ஊதியம், தொழிலாளர் நலம்',
    demoBadge: 'ஹேக்கத்தான் மாதிரி முறை',
    demoNotice: 'செயல்திறன் மாதிரி. QR வருகை பதிவு மற்றும் சம்பளச் சீட்டு விளக்கத்திற்காக உருவகப்படுத்தப்பட்டது.',
    switchSector: 'துறையை மாற்றவும்',
    construction: 'கட்டுமானத் துறை (Construction)',
    education: 'கல்வித்துறை (Education)',
    workerRole: 'தொழிலாளர் பக்கம்',
    adminRole: 'நிர்வாக டாஷ்போர்டு',
    roleSwitcher: 'பங்கை மாற்றவும்',

    navShifts: 'பணி நேர கண்காணிப்பு',
    navPayslip: 'சம்பளச் சீட்டு',
    navSafety: 'பாதுகாப்பு அறிக்கை',
    navFeedback: 'ரகசிய பின்னூட்டம்',
    navSkills: 'திறன் பாஸ்போர்ட்',
    navFatigue: 'களைப்பு எச்சரிக்கை',
    navAdmin: 'நிர்வாகப் பலகை',

    shiftsTitle: 'பணி அட்டவணை & வருகைப்பதிவு',
    shiftsSubtitle: 'உங்கள் திட்டமிட்ட பணிகளைப் பார்க்கவும், பணி நேரத்தை வெளிப்படையாகக் கண்காணிக்கவும்.',
    checkIn: 'பணியைத் தொடங்குக',
    checkOut: 'பணியை முடிக்கவும்',
    checkedInState: 'தற்போது பணியில் உள்ளீர்கள்',
    checkedOutState: 'பணி நிறைவு பெற்றது',
    simulateQR: 'QR வருகைப் பதிவு மாதிரி',
    qrModalTitle: 'தள வருகை QR ஸ்கேனர்',
    qrDisclaimer: 'மாதிரி QR பதிவு: நேரடி ஜி.பி.எஸ் இடத்தைக் கோராமல் உடனடி வருகையைச் சரிபார்க்கிறது.',
    scanNow: 'உடனடி ஸ்கேன் செய்க',
    close: 'மூடுக',
    weeklyHours: 'வாராந்திர மணிநேரம்',
    regularHours: 'வழக்கமான நேரம்',
    overtimeHours: 'கூடுதல் நேரம் (OT)',
    attendanceRate: 'நேரந்தவறாமை வீதம்',

    payslipTitle: 'வெளிப்படையான சம்பளச் சீட்டு',
    payslipSubtitle: 'அடிப்படை ஊதியம், கூடுதல் நேரக் கணக்கீடு மற்றும் சட்டப்பூர்வ பிடித்தங்களின் விரிவான விளக்கம்.',
    payslipSampleNote: 'விளக்க மாதிரி சம்பளச் சீட்டு — கணக்கீட்டைப் புரிந்துகொள்வதற்காக. இது அதிகாரப்பூர்வ ஆவணம் அல்ல.',
    earningsBreakdown: 'வருமான விவரம்',
    basePay: 'அடிப்படை ஊதியம்',
    overtimeEarnings: 'கூடுதல் நேர ஊதியம் (1.5x வீதம்)',
    allowance: 'தள & சிறப்புப் படி',
    grossPay: 'மொத்த வருமானம்',
    deductionsTitle: 'சட்டப்பூர்வ பிடித்தங்கள்',
    providentFund: 'வருங்கால வைப்பு நிதி (PF - 12%)',
    esiDeduction: 'ESI / மருத்துவக் காப்பீடு (0.75%)',
    profTax: 'தொழில் வரி',
    totalDeductions: 'மொத்தப் பிடித்தம்',
    netPayable: 'மதிப்பிடப்பட்ட கையில் கிடைக்கும் ஊதியம்',
    howCalculated: 'இது எவ்வாறு கணக்கிடப்பட்டது?',
    printPayslip: 'அச்சிட / சேமிக்க',
    pfExplanation: 'PF என்பது உங்கள் ஓய்வூதியத்திற்காக அடிப்படை ஊதியத்தில் 12% பிடித்தம் செய்யப்பட்டு முதலாளியாலும் சமமாகச் சேர்க்கப்படுகிறது.',
    otExplanation: '8 மணி நேரத்திற்கு மேல் பணிபுரியும் ஒவ்வொரு மணிக்கும் வழக்கமான ஊதியத்தை விட 1.5 மடங்கு கூடுதல் ஊதியம் அளிக்கப்படுகிறது.',
    esiExplanation: 'ESI திட்டம் உங்களுக்கும் உங்கள் குடும்பத்திற்கும் பணமில்லா மருத்துவமனைக் காப்பீட்டை வழங்குகிறது.',

    safetyTitle: 'பணியிட ஆபத்து & பாதுகாப்பு அறிக்கை',
    safetySubtitle: 'ஆபத்து தீவிரத்தன்மை, புகைப்படச் சான்று மற்றும் நிலையுடன் புகாரளிக்கவும்.',
    reportHazard: 'ஆபத்தைப் புகாரளிக்கவும்',
    hazardCategory: 'ஆபத்து வகை',
    hazardDescription: 'ஆபத்து மற்றும் துல்லியமான இடத்தின் விவரம்',
    hazardSeverity: 'தீவிரத்தன்மை நிலை',
    hazardLocation: 'பணியிட பகுதி / அறை',
    attachPhoto: 'புகைப்படச் சான்று சேர்க்க',
    voiceDictation: 'குரல் உள்ளீடு (Voice)',
    submitReport: 'அறிக்கையைச் சமர்ப்பிக்கவும்',
    reportSubmittedSuccess: 'பாதுகாப்பு அறிக்கை வெற்றிகரமாகப் பதிவு செய்யப்பட்டது! அறிக்கை எண்:',
    statusSubmitted: 'சமர்ப்பிக்கப்பட்டது',
    statusUnderReview: 'பரிசீலனையில்',
    statusResolved: 'தீர்க்கப்பட்டது',
    myReports: 'எனது பாதுகாப்பு அறிக்கைகள்',
    reportId: 'அறிக்கை எண்',

    feedbackTitle: 'நேர்மையான மற்றும் ரகசியக் கருத்து',
    feedbackSubtitle: 'பணிச் சூழல், பணிச்சுமை, வசதிகள் குறித்த உங்கள் கருத்துக்களைப் பகிரவும்.',
    feedbackTopic: 'பின்னூட்ட வகை',
    feedbackMessage: 'உங்கள் ரகசிய கருத்து',
    feedbackNoticeTitle: 'ரகசியத்தன்மை vs தொழில்நுட்ப அடையாளம் மறைத்தல்',
    feedbackNoticeBody: 'இந்த அறிக்கை மேற்பார்வையாளருக்கு உங்கள் பெயர் அல்லது ஐடி தெரியாமல் சேமிக்கப்படுகிறது. ஆனால் இது கிரிப்டோகிராஃபிக் (Tor போன்ற) அநாமதேய முறையைக் கொண்டிருக்கவில்லை.',
    submitFeedback: 'ரகசியக் கருத்தை அனுப்புக',
    feedbackSuccess: 'நன்றி. உங்கள் கருத்து நிர்வாகப் பார்வைக்காகப் பாதுகாப்பாகப் பதிவு செய்யப்பட்டது.',
    ratingLabel: 'பணியிட திருப்தி மதிப்பீடு',

    passportTitle: 'டிஜிட்டல் திறன் பாஸ்போர்ட்',
    passportSubtitle: 'சான்றளிக்கப்பட்ட பாதுகாப்புப் பயிற்சிகள் மற்றும் திறன்களின் முழுமையான பதிவு.',
    verifiedCredential: 'சரிபார்க்கப்பட்ட சான்றிதழ்',
    selfReported: 'சுய அறிவிப்புப் பதிவு',
    addRecord: 'புதிய திறன் / பயிற்சி சேர்க்க',
    downloadSummary: 'திறன் சுருக்கத்தை அச்சிடுக',
    trainingHours: 'பயிற்சி நேரம்',
    certNumber: 'சான்றிதழ் எண்',

    fatigueTitle: 'பணிச்சுமை மற்றும் களைப்பு எச்சரிக்கை',
    fatigueSubtitle: 'அதிகப்படியான வேலை நேரம் மற்றும் குறைந்த ஓய்வு இடைவெளிகளை முன்கூட்டியே கண்டறிதல்.',
    fatigueDisclaimer: 'அறிவிப்பு: கணக்கீட்டு விதி அடிப்படையிலான எச்சரிக்கை மட்டுமே. இது மருத்துவ நோயறிதல் அல்ல.',
    thresholdsTitle: 'பாதுகாப்பு வரம்புகள்',
    maxDailyHours: 'அதிகபட்ச தினசரி நேரம்',
    minRestBetweenShifts: 'குறைந்தபட்ச ஓய்வு இடைவெளி',
    maxConsecutiveDays: 'தொடர்ச்சியான வேலை நாட்கள்',
    statusNormal: 'பாதுகாப்பான வரம்பில் உள்ளது',
    statusWarning: 'களைப்பு எச்சரிக்கை நடைமுறையில் உள்ளது',

    adminTitle: 'பணியாளர் நலன் & நிர்வாக பலகை',
    adminSubtitle: 'வருகை, கூடுதல் நேரம், பாதுகாப்பு ஆபத்துகள் மற்றும் பணியாளர் கருத்துகளின் மேலாண்மை.',
    kpiWorkers: 'செயலில் உள்ள பணியாளர்கள்',
    kpiHours: 'மொத்த மணிநேரம்',
    kpiHazards: 'தீர்க்கப்படாத ஆபத்துகள்',
    kpiFatigue: 'களைப்பு எச்சரிக்கைகள்',
    kpiFeedback: 'மதிப்பீட்டு மதிப்பெண்',
    retentionTitle: 'சோதனை முறை ஊழியர் தக்கவைப்பு இடர் குறியீடு',
    retentionDisclaimer: 'சோதனை குறியீடு: இது தொடர் கூடுதல் நேரம் மற்றும் கருத்துகளின் அடிப்படையில் கணக்கிடப்படுகிறது. இது ஊழியர் விலகுவதற்கான உறுதியான கணிப்பு அல்ல.',
    actionListTitle: 'முன்னுரிமை நடவடிக்கை பட்டியல்',
    resolveAction: 'தீர்க்கப்பட்டது என குறிக்க',
    filterSector: 'துறை வடிகட்டி',
    allSectors: 'அனைத்துத் துறைகள்'
  }
};
