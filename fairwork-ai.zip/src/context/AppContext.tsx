import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  SectorType,
  UserRole,
  Language,
  WorkerProfile,
  ShiftRecord,
  SafetyReport,
  FeedbackEntry,
  SkillCredential,
  FatigueAlert,
  ThresholdSettings,
  SafetyStatus
} from '../types';
import {
  SAMPLE_WORKERS,
  ALL_CREW_MEMBERS,
  INITIAL_SHIFTS,
  INITIAL_SAFETY_REPORTS,
  INITIAL_FEEDBACK,
  INITIAL_SKILLS,
  INITIAL_FATIGUE_ALERTS,
  INITIAL_THRESHOLDS
} from '../data/mockData';
import { translations, TranslationDictionary } from '../i18n/translations';

interface AppContextType {
  sector: SectorType;
  setSector: (sector: SectorType) => void;
  role: UserRole;
  setRole: (role: UserRole) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: TranslationDictionary;
  activeWorker: WorkerProfile;
  setActiveWorker: (worker: WorkerProfile) => void;
  availableWorkers: WorkerProfile[];
  shifts: ShiftRecord[];
  currentShift?: ShiftRecord;
  clockIn: (location?: string, isSimulatedQR?: boolean) => void;
  clockOut: () => void;
  safetyReports: SafetyReport[];
  addSafetyReport: (report: Omit<SafetyReport, 'id' | 'timestamp' | 'status'>) => SafetyReport;
  updateSafetyReportStatus: (id: string, status: SafetyStatus, note?: string) => void;
  feedbackEntries: FeedbackEntry[];
  addFeedback: (entry: Omit<FeedbackEntry, 'id' | 'timestamp'>) => FeedbackEntry;
  skills: SkillCredential[];
  addSkillRecord: (skill: Omit<SkillCredential, 'id'>) => void;
  fatigueAlerts: FatigueAlert[];
  markFatigueReviewed: (id: string) => void;
  thresholds: ThresholdSettings;
  updateThresholds: (t: Partial<ThresholdSettings>) => void;
  resetAllDemoData: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  SECTOR: 'fairwork_sector_v1',
  ROLE: 'fairwork_role_v1',
  LANG: 'fairwork_lang_v1',
  SHIFTS: 'fairwork_shifts_v1',
  REPORTS: 'fairwork_reports_v1',
  FEEDBACK: 'fairwork_feedback_v1',
  SKILLS: 'fairwork_skills_v1',
  FATIGUE: 'fairwork_fatigue_v1',
  THRESHOLDS: 'fairwork_thresholds_v1',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sector, setSectorState] = useState<SectorType>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SECTOR);
    return (saved === 'education' || saved === 'construction') ? saved : 'construction';
  });

  const [role, setRoleState] = useState<UserRole>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ROLE);
    return (saved === 'admin' || saved === 'worker') ? saved : 'worker';
  });

  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LANG);
    return (saved === 'hi' || saved === 'ta' || saved === 'en') ? saved : 'en';
  });

  const [activeTab, setActiveTab] = useState<string>('shifts');

  const [activeWorker, setActiveWorker] = useState<WorkerProfile>(() => {
    return SAMPLE_WORKERS[sector];
  });

  // Keep active worker synchronized with sector changes unless manually changed
  const setSector = (newSector: SectorType) => {
    setSectorState(newSector);
    localStorage.setItem(STORAGE_KEYS.SECTOR, newSector);
    setActiveWorker(SAMPLE_WORKERS[newSector]);
  };

  const setRole = (newRole: UserRole) => {
    setRoleState(newRole);
    localStorage.setItem(STORAGE_KEYS.ROLE, newRole);
    if (newRole === 'admin') {
      setActiveTab('admin');
    } else if (activeTab === 'admin') {
      setActiveTab('shifts');
    }
  };

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem(STORAGE_KEYS.LANG, lang);
  };

  // Shifts state
  const [shifts, setShifts] = useState<ShiftRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SHIFTS);
      return saved ? JSON.parse(saved) : INITIAL_SHIFTS;
    } catch {
      return INITIAL_SHIFTS;
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SHIFTS, JSON.stringify(shifts));
  }, [shifts]);

  // Safety reports state
  const [safetyReports, setSafetyReports] = useState<SafetyReport[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.REPORTS);
      return saved ? JSON.parse(saved) : INITIAL_SAFETY_REPORTS;
    } catch {
      return INITIAL_SAFETY_REPORTS;
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify(safetyReports));
  }, [safetyReports]);

  // Feedback state
  const [feedbackEntries, setFeedbackEntries] = useState<FeedbackEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.FEEDBACK);
      return saved ? JSON.parse(saved) : INITIAL_FEEDBACK;
    } catch {
      return INITIAL_FEEDBACK;
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FEEDBACK, JSON.stringify(feedbackEntries));
  }, [feedbackEntries]);

  // Skills state
  const [skills, setSkills] = useState<SkillCredential[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SKILLS);
      return saved ? JSON.parse(saved) : INITIAL_SKILLS;
    } catch {
      return INITIAL_SKILLS;
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SKILLS, JSON.stringify(skills));
  }, [skills]);

  // Fatigue alerts
  const [fatigueAlerts, setFatigueAlerts] = useState<FatigueAlert[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.FATIGUE);
      return saved ? JSON.parse(saved) : INITIAL_FATIGUE_ALERTS;
    } catch {
      return INITIAL_FATIGUE_ALERTS;
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FATIGUE, JSON.stringify(fatigueAlerts));
  }, [fatigueAlerts]);

  // Thresholds
  const [thresholds, setThresholds] = useState<ThresholdSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.THRESHOLDS);
      return saved ? JSON.parse(saved) : INITIAL_THRESHOLDS;
    } catch {
      return INITIAL_THRESHOLDS;
    }
  });

  const updateThresholds = (newSettings: Partial<ThresholdSettings>) => {
    setThresholds((prev) => {
      const updated = { ...prev, ...newSettings };
      localStorage.setItem(STORAGE_KEYS.THRESHOLDS, JSON.stringify(updated));
      return updated;
    });
  };

  // Current active in-progress shift for current worker
  const currentShift = shifts.find(
    (s) => s.workerId === activeWorker.id && s.status === 'in_progress'
  );

  const clockIn = (location?: string, isSimulatedQR: boolean = true) => {
    if (currentShift) return; // already clocked in

    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toTimeString().slice(0, 5);

    const newShift: ShiftRecord = {
      id: `SH-LIVE-${Date.now().toString().slice(-5)}`,
      workerId: activeWorker.id,
      workerName: activeWorker.name,
      sector: activeWorker.sector,
      date: dateStr,
      scheduledStart: '08:00',
      scheduledEnd: '17:00',
      actualCheckIn: timeStr,
      breakMinutes: 0,
      regularHours: 0.1,
      overtimeHours: 0,
      status: 'in_progress',
      location: location || (sector === 'construction' ? 'SRM Site B Tower Core Station' : 'Tech Park Block 3 Workstation'),
      isSimulatedQR,
    };

    setShifts((prev) => [newShift, ...prev]);
  };

  const clockOut = () => {
    if (!currentShift) return;
    const now = new Date();
    const timeStr = now.toTimeString().slice(0, 5);

    setShifts((prev) =>
      prev.map((s) => {
        if (s.id === currentShift.id) {
          // calculate mock duration: at least 8 hours for completed demo realism
          const duration = 8.5;
          const reg = Math.min(duration, 8);
          const ot = Math.max(0, duration - 8);
          return {
            ...s,
            actualCheckOut: timeStr,
            status: 'completed',
            regularHours: reg,
            overtimeHours: Number(ot.toFixed(2)),
          };
        }
        return s;
      })
    );
  };

  const addSafetyReport = (reportData: Omit<SafetyReport, 'id' | 'timestamp' | 'status'>): SafetyReport => {
    const prefix = sector === 'construction' ? 'FW-CONST-2026' : 'FW-EDU-2026';
    const randomId = Math.floor(100 + Math.random() * 900);
    const newReport: SafetyReport = {
      ...reportData,
      id: `${prefix}-${randomId}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      status: 'submitted',
    };

    setSafetyReports((prev) => [newReport, ...prev]);
    return newReport;
  };

  const updateSafetyReportStatus = (id: string, status: SafetyStatus, note?: string) => {
    setSafetyReports((prev) =>
      prev.map((r) => {
        if (r.id === id) {
          return {
            ...r,
            status,
            resolutionNote: note || r.resolutionNote,
            resolvedAt: status === 'resolved' ? new Date().toISOString().replace('T', ' ').slice(0, 16) : r.resolvedAt,
            reviewedBy: 'Admin Operations Desk',
          };
        }
        return r;
      })
    );
  };

  const addFeedback = (entryData: Omit<FeedbackEntry, 'id' | 'timestamp'>): FeedbackEntry => {
    const prefix = sector === 'construction' ? 'FB-C' : 'FB-E';
    const randomId = Math.floor(500 + Math.random() * 500);
    const newEntry: FeedbackEntry = {
      ...entryData,
      id: `${prefix}-${randomId}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
    };

    setFeedbackEntries((prev) => [newEntry, ...prev]);
    return newEntry;
  };

  const addSkillRecord = (skillData: Omit<SkillCredential, 'id'>) => {
    const prefix = sector === 'construction' ? 'SK-C' : 'SK-E';
    const newRecord: SkillCredential = {
      ...skillData,
      id: `${prefix}-${Date.now().toString().slice(-4)}`,
    };
    setSkills((prev) => [newRecord, ...prev]);
  };

  const markFatigueReviewed = (id: string) => {
    setFatigueAlerts((prev) =>
      prev.map((a) => (a.id === id ? { ...a, reviewed: true } : a))
    );
  };

  const resetAllDemoData = () => {
    setShifts(INITIAL_SHIFTS);
    setSafetyReports(INITIAL_SAFETY_REPORTS);
    setFeedbackEntries(INITIAL_FEEDBACK);
    setSkills(INITIAL_SKILLS);
    setFatigueAlerts(INITIAL_FATIGUE_ALERTS);
    setThresholds(INITIAL_THRESHOLDS);
    setSectorState('construction');
    setRoleState('worker');
    setActiveWorker(SAMPLE_WORKERS.construction);
    setActiveTab('shifts');
    localStorage.clear();
  };

  const availableWorkers = ALL_CREW_MEMBERS.filter((w) => w.sector === sector);

  const t = translations[language];

  return (
    <AppContext.Provider
      value={{
        sector,
        setSector,
        role,
        setRole,
        language,
        setLanguage,
        t,
        activeWorker,
        setActiveWorker,
        availableWorkers,
        shifts,
        currentShift,
        clockIn,
        clockOut,
        safetyReports,
        addSafetyReport,
        updateSafetyReportStatus,
        feedbackEntries,
        addFeedback,
        skills,
        addSkillRecord,
        fatigueAlerts,
        markFatigueReviewed,
        thresholds,
        updateThresholds,
        resetAllDemoData,
        activeTab,
        setActiveTab,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
