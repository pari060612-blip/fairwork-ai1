export type SectorType = 'construction' | 'education';
export type UserRole = 'worker' | 'admin';
export type Language = 'en' | 'hi' | 'ta';

export type SafetySeverity = 'low' | 'medium' | 'high' | 'critical';
export type SafetyStatus = 'submitted' | 'under_review' | 'resolved';

export interface WorkerProfile {
  id: string;
  name: string;
  role: string;
  sector: SectorType;
  departmentOrSite: string;
  supervisor: string;
  avatarText: string;
  hourlyRate: number; // in INR
  baseMonthlyRate?: number;
  phone: string;
  joiningDate: string;
}

export interface ShiftRecord {
  id: string;
  workerId: string;
  workerName: string;
  sector: SectorType;
  date: string;
  scheduledStart: string;
  scheduledEnd: string;
  actualCheckIn?: string;
  actualCheckOut?: string;
  breakMinutes: number;
  regularHours: number;
  overtimeHours: number;
  status: 'completed' | 'in_progress' | 'scheduled' | 'missed';
  location: string;
  isSimulatedQR?: boolean;
}

export interface SafetyReport {
  id: string;
  workerId: string;
  sector: SectorType;
  category: string;
  title: string;
  description: string;
  severity: SafetySeverity;
  location: string;
  status: SafetyStatus;
  timestamp: string;
  imageUrl?: string;
  imageCaption?: string;
  voiceRecorded?: boolean;
  resolutionNote?: string;
  resolvedAt?: string;
  reviewedBy?: string;
}

export interface FeedbackEntry {
  id: string;
  workerId: string; // Stored securely internally, never shown publicly
  sector: SectorType;
  topic: string;
  rating: number; // 1-5
  message: string;
  timestamp: string;
  sentiment: 'positive' | 'neutral' | 'concern';
  isConfidential: boolean;
}

export interface SkillCredential {
  id: string;
  workerId: string;
  sector: SectorType;
  title: string;
  category: string;
  issuingAuthority: string;
  issueDate: string;
  expiryDate?: string;
  verificationType: 'verified_official' | 'self_reported';
  credentialId?: string;
  description: string;
  trainingHours: number;
}

export interface FatigueAlert {
  id: string;
  workerId: string;
  workerName: string;
  sector: SectorType;
  departmentOrSite: string;
  date: string;
  severity: 'moderate' | 'high' | 'severe';
  triggerReason: string;
  loggedHours: number;
  thresholdHours: number;
  turnaroundHours?: number;
  consecutiveDays: number;
  recommendedAction: string;
  reviewed: boolean;
}

export interface ThresholdSettings {
  maxDailyHours: number;
  minTurnaroundHours: number;
  maxConsecutiveDays: number;
}
