/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { DemoBanner } from './components/DemoBanner';
import { Header } from './components/Header';
import { ShiftTracker } from './components/WorkerPortal/ShiftTracker';
import { ClearPayslip } from './components/WorkerPortal/ClearPayslip';
import { SafetyReporter } from './components/WorkerPortal/SafetyReporter';
import { HonestFeedback } from './components/WorkerPortal/HonestFeedback';
import { SkillPassport } from './components/WorkerPortal/SkillPassport';
import { FatigueMonitor } from './components/WorkerPortal/FatigueMonitor';
import { AdminDashboard } from './components/AdminPortal/AdminDashboard';
import {
  HardHat,
  GraduationCap,
  ShieldCheck,
  UserCheck,
  ArrowRight,
  Info,
  ExternalLink,
  Layers
} from 'lucide-react';

const MainContent: React.FC = () => {
  const {
    role,
    setRole,
    sector,
    setSector,
    activeTab,
    setActiveTab,
    activeWorker,
    availableWorkers,
    setActiveWorker,
  } = useApp();

  const [showArchitectureModal, setShowArchitectureModal] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      {/* Hackathon Top Bar & Quick Switcher */}
      <DemoBanner />

      {/* Primary Brand Top Bar */}
      <Header />

      {/* Main Workspace Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Sector & Worker Profile Context Bar */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-4 mb-6 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4 no-print">
          <div className="flex items-center gap-3">
            <div
              className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                sector === 'construction'
                  ? 'bg-emerald-100 text-emerald-900'
                  : 'bg-teal-100 text-teal-900'
              }`}
            >
              {sector === 'construction' ? (
                <HardHat className="w-6 h-6" />
              ) : (
                <GraduationCap className="w-6 h-6" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-teal-800">
                  Active Industry Sector
                </span>
                <span className="text-slate-300">·</span>
                <span className="text-xs font-semibold text-slate-700 capitalize">
                  {sector}
                </span>
              </div>
              <h2 className="text-sm font-bold text-slate-900 mt-0.5">
                {sector === 'construction'
                  ? 'SRM Site B Infrastructure Project (Chennai)'
                  : 'SRMIST Academic & Research Labs (Kattankulathur)'}
              </h2>
            </div>
          </div>

          {/* Quick Profile Selector for Demo Exploration */}
          <div className="flex items-center gap-3 flex-wrap">
            <div className="text-xs text-slate-500">
              <span className="text-slate-400 block text-[11px]">Demo Personnel:</span>
              <div className="flex items-center gap-1.5 mt-0.5">
                {availableWorkers.map((w) => (
                  <button
                    key={w.id}
                    type="button"
                    onClick={() => setActiveWorker(w)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-all ${
                      activeWorker.id === w.id
                        ? 'bg-slate-900 text-white border-slate-900 font-semibold shadow-2xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {w.name.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>

            <div className="h-8 w-px bg-slate-200 hidden sm:block"></div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setRole(role === 'worker' ? 'admin' : 'worker')}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold border border-slate-200 hover:bg-slate-50 transition-colors flex items-center gap-1.5 text-slate-700"
              >
                {role === 'worker' ? (
                  <>
                    <ShieldCheck className="w-3.5 h-3.5 text-teal-800" />
                    <span>Switch to Admin Mode</span>
                  </>
                ) : (
                  <>
                    <UserCheck className="w-3.5 h-3.5 text-slate-700" />
                    <span>Switch to Worker Mode</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setShowArchitectureModal(true)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium text-teal-800 bg-teal-50 hover:bg-teal-100 transition-colors flex items-center gap-1 border border-teal-200"
                title="View Hackathon System Architecture & Production Deployment Notes"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Architecture</span>
              </button>
            </div>
          </div>
        </div>

        {/* Tab Router View */}
        {role === 'admin' ? (
          <AdminDashboard />
        ) : (
          <div>
            {activeTab === 'shifts' && <ShiftTracker />}
            {activeTab === 'payslip' && <ClearPayslip />}
            {activeTab === 'safety' && <SafetyReporter />}
            {activeTab === 'feedback' && <HonestFeedback />}
            {activeTab === 'skills' && <SkillPassport />}
            {activeTab === 'fatigue' && <FatigueMonitor />}
          </div>
        )}
      </main>

      {/* Production Readiness & Architecture Modal */}
      {showArchitectureModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-teal-800" />
                <h3 className="text-base font-bold text-slate-900">
                  FairWork AI — System Architecture & Cloud Run Deployment
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowArchitectureModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
              <p>
                Built for <strong>Prompt Wars 2026 at SRMIST</strong> to make work fairer, safer, and more transparent across <strong>Construction</strong> and <strong>Education</strong> sectors.
              </p>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <strong className="text-slate-900 block font-semibold">How to Run & Test the Application:</strong>
                <ul className="list-disc list-inside space-y-1 text-slate-700">
                  <li><strong>Sector Switching:</strong> Toggle between Construction and Education using the top demo bar. Observe terminology, hazard categories, skills, and payslip data adapt seamlessly.</li>
                  <li><strong>Shift & Simulated QR:</strong> Open Shift Tracker and click "Simulate QR Check-In" to test instant attendance logging without real GPS tracking.</li>
                  <li><strong>Clear Multilingual Payslips:</strong> Toggle English, Hindi, and Tamil to inspect the transparent 1.5x overtime formula and deduction explanations.</li>
                  <li><strong>Safety Reporting & Voice Input:</strong> Report a hazard using either typed text or accessible Web Speech voice recognition. Form submission auto-generates a tracking ID and persists into the Admin Dashboard.</li>
                  <li><strong>Fatigue Monitor:</strong> Inspect mathematical threshold triggers and configure demo parameters (max hours, rest intervals) without medical claims.</li>
                  <li><strong>Admin Console:</strong> Switch role to Admin to view real-time SVG charts, manage the hazard resolution queue, and inspect the experimental retention indicator with limitations disclosed.</li>
                </ul>
              </div>

              <div className="p-3 bg-teal-50/60 rounded-xl border border-teal-200 text-teal-950 space-y-1">
                <strong className="block font-semibold text-teal-900">
                  Production Deployment & Backend Integration Plan (Google Cloud Run):
                </strong>
                <p>
                  In this hackathon evaluation build, all submissions and shift states persist in client <code>localStorage</code> with zero external paid APIs required. For enterprise production on Google Cloud Run:
                </p>
                <ol className="list-decimal list-inside space-y-1 text-slate-700 pt-1">
                  <li><strong>Relational DB / Firestore:</strong> Wire Express server to PostgreSQL/Firestore for multi-tenant worker timecards and audit logs.</li>
                  <li><strong>Biometric / Optical Token Gateway:</strong> Connect simulated QR endpoints to site-mounted turnstiles with HMAC-SHA256 optical tokens.</li>
                  <li><strong>Govt Payroll Compliance:</strong> Integrate official EPFO (Provident Fund) and ESIC API webhooks for automated statutory filings.</li>
                  <li><strong>Zero-Knowledge Confidentiality:</strong> Upgrade feedback pipeline with blind signatures to ensure cryptographic anonymity for whistleblower protections.</li>
                </ol>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setShowArchitectureModal(false)}
                className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
              >
                Close Architecture Overview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 mt-12 text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-900">FairWork AI</span>
            <span>·</span>
            <span>Prompt Wars 2026 at SRMIST</span>
            <span>·</span>
            <span className="text-emerald-700 font-medium">Construction & Education Workforce Health</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Client State Persisted</span>
            <span>·</span>
            <button
              type="button"
              onClick={() => setShowArchitectureModal(true)}
              className="text-teal-800 hover:underline font-medium"
            >
              Cloud Run Deployment Notes
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
